CREATE DATABASE  IF NOT EXISTS `airline_reservation_system` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `airline_reservation_system`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: airline_reservation_system
-- ------------------------------------------------------
-- Server version	5.5.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking_detail`
--

DROP TABLE IF EXISTS `booking_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_detail` (
  `booking_id` varchar(45) DEFAULT NULL,
  `customer_name` varchar(45) DEFAULT NULL,
  `airline_name` varchar(45) DEFAULT NULL,
  `leaving_from` varchar(45) DEFAULT NULL,
  `going_to` varchar(45) DEFAULT NULL,
  `departure_time` varchar(45) DEFAULT NULL,
  KEY `booking_id_fk1` (`booking_id`),
  CONSTRAINT `booking_id_fk1` FOREIGN KEY (`booking_id`) REFERENCES `booking_info` (`booking_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_detail`
--

LOCK TABLES `booking_detail` WRITE;
/*!40000 ALTER TABLE `booking_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssn_master`
--

DROP TABLE IF EXISTS `ssn_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssn_master` (
  `ssn_type` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`ssn_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssn_master`
--

LOCK TABLES `ssn_master` WRITE;
/*!40000 ALTER TABLE `ssn_master` DISABLE KEYS */;
INSERT INTO `ssn_master` VALUES ('DRIVING LICENCE'),('PAN CARD'),('PASSPORT'),('VOTER-ID CARD');
/*!40000 ALTER TABLE `ssn_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_temp_master`
--

DROP TABLE IF EXISTS `search_temp_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_temp_master` (
  `f_no` varchar(45) DEFAULT NULL,
  `a_name` varchar(45) DEFAULT NULL,
  `src` varchar(45) DEFAULT NULL,
  `depart_time` varchar(45) DEFAULT NULL,
  `dest` varchar(45) DEFAULT NULL,
  `fare` int(10) DEFAULT NULL,
  `dept_date` varchar(45) DEFAULT NULL,
  `no_of_seats` int(10) DEFAULT NULL,
  KEY `f_no_search_temp_master_fk` (`f_no`),
  CONSTRAINT `f_no_search_temp_master_fk` FOREIGN KEY (`f_no`) REFERENCES `flight_master` (`f_no`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_temp_master`
--

LOCK TABLES `search_temp_master` WRITE;
/*!40000 ALTER TABLE `search_temp_master` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_temp_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_master`
--

DROP TABLE IF EXISTS `location_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_master` (
  `location_id` int(11) DEFAULT NULL,
  `location_name` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_master`
--

LOCK TABLES `location_master` WRITE;
/*!40000 ALTER TABLE `location_master` DISABLE KEYS */;
INSERT INTO `location_master` VALUES (3,'Chennai'),(2,'Delhi'),(5,'Hyderabad'),(1,'Kolkata'),(4,'Mumbai');
/*!40000 ALTER TABLE `location_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seats_available`
--

DROP TABLE IF EXISTS `seats_available`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seats_available` (
  `serial_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_no` varchar(45) NOT NULL,
  `ava_seats` int(11) NOT NULL,
  `dept_date` varchar(45) NOT NULL,
  PRIMARY KEY (`serial_id`),
  KEY `asd` (`f_no`),
  CONSTRAINT `f_no_seats_available_fk` FOREIGN KEY (`f_no`) REFERENCES `flight_master` (`f_no`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats_available`
--

LOCK TABLES `seats_available` WRITE;
/*!40000 ALTER TABLE `seats_available` DISABLE KEYS */;
INSERT INTO `seats_available` VALUES (1,'F1',90,'01-02-2015'),(2,'F2',92,'10-02-2015'),(3,'F3',84,'31-03-2015'),(4,'F4',40,'04-08-2015'),(5,'F20',49,'31-03-2015');
/*!40000 ALTER TABLE `seats_available` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `airlines_master`
--

DROP TABLE IF EXISTS `airlines_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `airlines_master` (
  `a_id` varchar(45) NOT NULL,
  `a_name` varchar(45) NOT NULL,
  `dop` varchar(45) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `airlines_master`
--

LOCK TABLES `airlines_master` WRITE;
/*!40000 ALTER TABLE `airlines_master` DISABLE KEYS */;
INSERT INTO `airlines_master` VALUES ('A1','Indigo','23.01.2000'),('A2','Kingfisher','24.02.2001'),('A3','Jet Airways','25.03.2002'),('A4','Spice Jet','26.04.2003');
/*!40000 ALTER TABLE `airlines_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flight_master`
--

DROP TABLE IF EXISTS `flight_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flight_master` (
  `f_no` varchar(5) NOT NULL DEFAULT '',
  `a_id` varchar(45) DEFAULT NULL,
  `tot_seats` int(11) NOT NULL,
  `src` varchar(7) NOT NULL,
  `dest` varchar(7) NOT NULL,
  `depart_time` varchar(5) NOT NULL,
  `fare` int(11) NOT NULL,
  PRIMARY KEY (`f_no`),
  KEY `A_ID` (`a_id`),
  KEY `SRC` (`src`),
  KEY `DEST` (`dest`),
  CONSTRAINT `aid_flight_master_fk` FOREIGN KEY (`a_id`) REFERENCES `airlines_master` (`a_id`),
  CONSTRAINT `dest_flight_master_fk` FOREIGN KEY (`dest`) REFERENCES `location_master` (`location_name`),
  CONSTRAINT `src_flight_master_fk` FOREIGN KEY (`src`) REFERENCES `location_master` (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flight_master`
--

LOCK TABLES `flight_master` WRITE;
/*!40000 ALTER TABLE `flight_master` DISABLE KEYS */;
INSERT INTO `flight_master` VALUES ('F1','A1',100,'Kolkata','Delhi','07:30',7000),('F10','A2',100,'Mumbai','Delhi','11:00',7600),('F11','A3',100,'Delhi','Mumbai','19:30',4500),('F12','A4',100,'Mumbai','Delhi','20:00',8000),('F2','A1',100,'Delhi','Kolkata','06:30',7500),('F20','A3',100,'Chennai','Mumbai','16:30',10000),('F3','A2',100,'Chennai','Mumbai','16:30',8000),('F4','A2',100,'Mumbai','Chennai','08:30',7500),('F5','A3',100,'Kolkata','Mumbai','13:00',5000),('F6','A3',100,'Mumbai','Kolkata','14:00',6000),('F7','A4',100,'Chennai','Delhi','03:00',6500),('F8','A4',100,'Delhi','Chennai','09:00',8900),('F9','A1',100,'Kolkata','Chennai','10:00',9000);
/*!40000 ALTER TABLE `flight_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_info`
--

DROP TABLE IF EXISTS `booking_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_info` (
  `booking_id` varchar(45) NOT NULL,
  `booking_date` varchar(45) DEFAULT NULL,
  `f_no` varchar(5) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `seat_book` int(11) DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  KEY `f_no_booking_info_fk` (`f_no`),
  KEY `cid_booking_info_fk` (`cid`),
  CONSTRAINT `cid_booking_info_fk` FOREIGN KEY (`cid`) REFERENCES `customer_info` (`cid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `f_no_booking_info_fk` FOREIGN KEY (`f_no`) REFERENCES `flight_master` (`f_no`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_info`
--

LOCK TABLES `booking_info` WRITE;
/*!40000 ALTER TABLE `booking_info` DISABLE KEYS */;
INSERT INTO `booking_info` VALUES ('ABK0011','31-01-2015','F20',2,10000,1),('ABK0012','31-01-2015','F20',2,10000,1),('ABK0013','31-01-2015','F20',2,9850,1),('ABK0014','31-01-2015','F20',2,19850,2),('ABK0015','31-01-2015','F20',2,9850,1),('ABK0016','31-01-2015','F20',2,9850,1),('ABK0017','31-01-2015','F20',2,19850,2),('ABK0018','31-01-2015','F20',2,29550,3),('ABK0019','31-01-2015','F20',2,9850,1),('ABK0020','31-01-2015','F20',2,9850,1),('ABK0021','31-01-2015','F20',2,9850,1),('ABK0022','31-01-2015','F20',2,19700,2),('ABK0023','31-01-2015','F20',2,9850,1),('ABK0024','31-01-2015','F20',2,9850,1),('ABK0025','31-01-2015','F20',2,9850,1),('ABK0026','31-01-2015','F20',2,9850,1),('ABK0027','31-01-2015','F20',2,9850,1),('ABK0028','31-01-2015','F20',2,9850,1),('ABK0029','31-01-2015','F20',2,9850,1),('ABK0030','31-01-2015','F20',2,9850,1),('ABK0031','31-01-2015','F20',2,9850,1),('ABK0032','31-01-2015','F20',2,9850,1),('ABK0033','31-01-2015','F20',2,9850,1),('ABK0035','31-01-2015','F20',2,9850,1),('ABK0038','31-01-2015','F20',2,9850,1),('ABK0039','31-01-2015','F20',2,9850,1),('ABK0041','31-01-2015','F20',2,9850,1),('ABK0043','31-01-2015','F20',2,19700,2),('ABK0044','31-01-2015','F20',2,19700,2),('ABK0045','31-01-2015','F20',2,19700,2),('ABK0046','31-01-2015','F20',2,19700,2),('ABK0047','31-01-2015','F20',2,19700,2),('ABK0048','31-01-2015','F20',2,9850,1),('ABK0049','31-01-2015','F20',2,19700,2),('ABK0051','02-02-2015','F20',2,9850,1),('ABK0052','02-02-2015','F3',2,7850,1),('ABK0053','02-02-2015','F3',2,7850,1),('ABK0054','02-02-2015','F3',2,7850,1),('ABK0055','02-02-2015','F20',14,39400,4),('ABK0056','02-02-2015','F20',2,9850,1),('ABK0057','02-02-2015','F20',2,9850,1),('ABK0058','02-02-2015','F20',2,9850,1),('ABK0059','02-02-2015','F20',2,9850,1),('ABK0060','02-02-2015','F20',2,9850,1),('ABK0061','02-02-2015','F20',2,9850,1),('ABK0062','02-02-2015','F20',2,9850,1),('ABK0063','02-02-2015','F20',2,9850,1),('ABK0064','02-02-2015','F20',2,9850,1),('ABK0065','02-02-2015','F20',2,9850,1),('ABK0066','02-02-2015','F20',2,9850,1),('ABK0067','02-02-2015','F20',2,9850,1),('ABK0068','03-02-2015','F20',2,9850,1),('ABK0069','03-02-2015','F20',2,9850,1),('ABK0070','03-02-2015','F20',2,9850,1);
/*!40000 ALTER TABLE `booking_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cancel_history`
--

DROP TABLE IF EXISTS `cancel_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancel_history` (
  `cid` varchar(45) DEFAULT NULL,
  `total` varchar(45) DEFAULT NULL,
  `charge` double DEFAULT NULL,
  `refund` double DEFAULT NULL,
  `booking_id` varchar(45) DEFAULT NULL,
  `cancel_tax` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancel_history`
--

LOCK TABLES `cancel_history` WRITE;
/*!40000 ALTER TABLE `cancel_history` DISABLE KEYS */;
INSERT INTO `cancel_history` VALUES ('1','7000',3500,3500,'ABK0010',NULL),('1','7000',3500,3500,'ABK0011',NULL),('1','7000',3500,3500,'ABK0013',NULL),('1','28000',14000,14000,'ABK001',NULL),('1','30000',0,0,'ABK0050',NULL),('2','30000',0,0,'ABK002',NULL),('2','30000',0,0,'ABK002',NULL),('2','30000',0,0,'ABK002',NULL),('2','30000',0,0,'ABK002',NULL),('2','30000',0,0,'ABK003',NULL),('2','10000',0,0,'ABK004',NULL),('2','30000',0,0,'ABK005',NULL),('2','30000',0,0,'ABK007',NULL),('2','10000',0,0,'ABK0010',NULL),('2','30000',0,0,'ABK009',NULL),('2','7850',0,0,'ABK0034',NULL),('2','10000',0,0,'ABK0010',NULL),('2','7850',785,7065,'ABK0036',NULL),('2','7850',785,7065,'ABK0037',NULL),('2','7850',785,7065,'ABK0040',NULL),('2','7850',785,6908,'ABK0042',157),('2','15700',1570,13816,'ABK0050',314);
/*!40000 ALTER TABLE `cancel_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_info`
--

DROP TABLE IF EXISTS `customer_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_info` (
  `cname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `address` varchar(145) NOT NULL,
  `phone` bigint(25) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `ssn_type` varchar(25) NOT NULL,
  `ssn_no` varchar(45) NOT NULL,
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`cid`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `Ssn_type` (`ssn_type`),
  CONSTRAINT `ssn_type_customer_info_fk` FOREIGN KEY (`ssn_type`) REFERENCES `ssn_master` (`ssn_type`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_info`
--

LOCK TABLES `customer_info` WRITE;
/*!40000 ALTER TABLE `customer_info` DISABLE KEYS */;
INSERT INTO `customer_info` VALUES ('Saurabh Bhaitia','saurabhbhatiazx@gmail.com','@Anusha123','12-12-1997','Preet Enclave',8798745652,'M','PAN CARD','12345',1),('Ishant Aggarwal','hello@gmail.com','ishant1@','1992-07-15','Cognizant',8146068870,'','PAN CARD','ghhdfkg45',2),('Deepanshu','deepu@yahoo.com','@ishantag','1992-4-7','Hyderabad',9874562315,'M','PAN CARD','asfajg343',3),('Saurabh','saurabh@go.com','saurabh1@','1992-02-05','Hno 104',8146068870,'Male','DRIVING LICENCE','fgdfgdfg',4),('saurabh','a@gmil.com','saurabh1@','2015-01-06','defdf',8146068870,'Male','DRIVING LICENCE','qw',5),('deepanshu','d@ghj.com','deepanshu1@','2015-01-30','wer',8146068870,'Male','DRIVING LICENCE','de',6),('Saurabh Bhatia','abc@gmail.com','saurabh1@','2015-01-05','Hno',8146068870,'Male','DRIVING LICENCE','wded',7),('saurabh bhatia','a@gmail.com','saurabh1@','2015-01-05','dddd',8146068870,'Male','DRIVING LICENCE','dsadsd',9),('Deepanshu','deep@gmail.com','deepanshu1@','02/02/2015','asdfdf',8146068870,'Male','PAN CARD','sdfdf23',14);
/*!40000 ALTER TABLE `customer_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_temp_master`
--

DROP TABLE IF EXISTS `invoice_temp_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_temp_master` (
  `customer_name` varchar(45) DEFAULT NULL,
  `airline_name` varchar(45) DEFAULT NULL,
  `f_no` varchar(5) DEFAULT NULL,
  `leaving_from` varchar(45) DEFAULT NULL,
  `going_to` varchar(45) DEFAULT NULL,
  `seat_book` int(11) DEFAULT NULL,
  `booking_date` varchar(45) DEFAULT NULL,
  `tot_price` int(11) DEFAULT NULL,
  KEY `Leaving From` (`leaving_from`),
  KEY `Going To` (`going_to`),
  KEY `fno_invoice_temp_master_fk` (`f_no`),
  KEY `cid_invoice_temp_master_fk` (`customer_name`),
  CONSTRAINT `fno_invoice_temp_master_fk` FOREIGN KEY (`f_no`) REFERENCES `flight_master` (`f_no`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `going_to_invoice_temp_master_fk` FOREIGN KEY (`going_to`) REFERENCES `location_master` (`location_name`),
  CONSTRAINT `leaving_from_invoice_temp_master_fk` FOREIGN KEY (`leaving_from`) REFERENCES `location_master` (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_temp_master`
--

LOCK TABLES `invoice_temp_master` WRITE;
/*!40000 ALTER TABLE `invoice_temp_master` DISABLE KEYS */;
INSERT INTO `invoice_temp_master` VALUES ('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',10000),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',3,'31-01-2015',29550),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'31-01-2015',7850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',2,'31-01-2015',15700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'31-01-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'31-01-2015',19700),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',2,'02-02-2015',15700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'02-02-2015',7850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'02-02-2015',7850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'02-02-2015',7850),('Ishant Aggarwal','Kingfisher','F3','Chennai','Mumbai',1,'02-02-2015',7850),('Deepanshu','Jet Airways','F20','Chennai','Mumbai',4,'02-02-2015',39400),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',2,'02-02-2015',19700),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'02-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'03-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'03-02-2015',9850),('Ishant Aggarwal','Jet Airways','F20','Chennai','Mumbai',1,'03-02-2015',9850);
/*!40000 ALTER TABLE `invoice_temp_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travelling_details`
--

DROP TABLE IF EXISTS `travelling_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travelling_details` (
  `booking_id` varchar(45) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `passenger_name` varchar(45) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(45) NOT NULL,
  KEY `booking_id_travelling_details_fk` (`booking_id`),
  KEY `cid_travelling_details_fk` (`cust_id`),
  CONSTRAINT `cid_travelling_details_fk` FOREIGN KEY (`cust_id`) REFERENCES `customer_info` (`cid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travelling_details`
--

LOCK TABLES `travelling_details` WRITE;
/*!40000 ALTER TABLE `travelling_details` DISABLE KEYS */;
INSERT INTO `travelling_details` VALUES ('ABK0010',1,'dffff',25,'Male'),('ABK0011',1,'dfgdf',25,'Male'),('ABK0012',1,'saurabh bhatia',25,'Male'),('ABK0013',1,'saurabh',26,'Male'),('ABK0014',1,'saurabh',25,'Male'),('ABK0016',1,'saurabh',25,'Male'),('ABK0017',1,'ddddd',12,'Male'),('ABK0019',1,'Saurabh Bhatia',25,'Male'),('ABK0020',1,'Sachin Bansal',78,'Male'),('ABK0031',1,'Saurabh',25,'Male'),('ABK0032',1,'ss',26,'Male'),('ABK0033',1,'Saurabh',25,'Male'),('ABK0035',1,'sss',25,'Male'),('ABK0036',1,'sss',26,'Male'),('ABK0037',1,'sss',26,'Male'),('ABK0038',1,'sss',26,'Male'),('ABK0039',1,'sss',26,'Male'),('ABK0040',1,'ssss',2,'Male'),('ABK0041',1,'dd',26,'Male'),('ABK0042',1,'sss',1,'Female'),('ABK0043',1,'ss',26,'Male'),('ABK0044',1,'sss',25,'Male'),('ABK0045',1,'ss',26,'Male'),('ABK0046',1,'Saurabh Bhatia',25,'Male'),('ABK0047',1,'sss',25,'Male'),('ABK0048',1,'ddd',26,'Male'),('ABK0048',1,'ss',26,'Male'),('ABK0049',1,'lj',26,'Male'),('ABK0050',1,'saurabh',25,'Male'),('ABK0051',1,'jg',25,'Male'),('ABK0052',1,'ss',26,'Male'),('ABK0053',1,'sss',25,'Male'),('ABK0054',1,'ss',26,'Male'),('ABK0054',1,'ss',26,'Male'),('ABK0054',1,'ss',26,'Male'),('ABK0054',1,'sss',26,'Male'),('ABK0054',1,'dsdd',26,'Male'),('ABK0054',1,'hjjv',25,'Male'),('ABK0055',1,'azaad',20,'Male'),('ABK0056',1,'ss',26,'Male'),('ABK0057',1,'Saurabh Bhatia',25,'Male'),('ABK0058',1,'Saurabh',21,'Male'),('ABK0072',1,'Saurabh',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0059',1,'Saurabh Bhatia',22,'Male'),('ABK0072',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK0014',1,'Saurabh Bhatia',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK0015',1,'sau',22,'Male'),('ABK0016',1,'Saurabh Bhatia',22,'Male'),('ABK0017',1,'saurabh',22,'Male'),('ABK0018',1,'Saurabh',22,'Male'),('ABK0019',1,'Saurabh Bhatia',22,'Male'),('ABK0019',1,'Saurabh',22,'Male'),('ABK0059',1,'Mohit Kumar',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Deepanshu Kumar',22,'Male'),('ABK0059',1,'Mohit Kumar',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Deepanshu Kumar',22,'Male'),('ABK0059',1,'Mohit Kumar',22,'Male'),('ABK0014',1,'Saurabh Bhatia',22,'Saurabh Bhatia'),('ABK00051',1,'Saurabh Bhatia',22,'Male'),('ABK0051',1,'Deepanshu Kumar',22,'Male'),('ABK0020',1,'sss',22,'Male'),('ABK0020',1,'SAU',23,'Male'),('ABK0021',1,'sa',22,'Male'),('ABK0021',1,'sa',23,'Male'),('ABK0022',1,'ss',26,'Male'),('ABK0022',1,'Saurabh',25,'Male'),('ABK0023',1,'tyy',22,'Male'),('ABK0023',1,'dd',22,'Male'),('ABK0024',1,'Saurabh Bhatia',22,'Male'),('ABK0024',1,'Rohit',22,'Male'),('ABK0025',1,'Saurabh',22,'Male'),('ABK0025',1,'Rohit',22,'Male'),('ABK0025',1,'Rohan',22,'Male'),('ABK0025',1,'Lohi',22,'Male'),('ABK0026',1,'saurabh',22,'Male'),('ABK0026',1,'Rohan',23,'Male'),('ABK0027',1,'Saurabh Bhatia',22,'Male'),('ABK0027',1,'ergfrgf',22,'Male'),('ABK0027',1,'Deepu',22,'Male'),('ABK0027',1,'Ishant',22,'Male'),('ABK0027',1,'Thapi',50,'Male'),('ABK0028',1,'saurabh',22,'Male'),('ABK0028',1,'Deepu',22,'Male'),('ABK0029',1,'sdsdsd',22,'Male'),('ABK0030',1,'fg',32,'Male'),('ABK0031',1,'as',2,'Male'),('ABK0032',1,'ad',21,'Male'),('ABK0033',1,'sss',22,'Male'),('ABK0034',1,'Saurabh',22,'Male'),('ABK0034',1,'Radhika',23,'Female'),('ABK0034',1,'Saurabh',22,'Male'),('ABK0035',1,'Saurabh',22,'Male'),('ABK0035',1,'Radhika',23,'Female'),('ABK0035',1,'Saurabh',22,'Male'),('ABK0036',1,'Saurabh',22,'Male'),('ABK0036',1,'Radhika',23,'Female'),('ABK0036',1,'Saurabh',22,'Male'),('ABK0037',1,'Saurabh',22,'Male'),('ABK0037',1,'Radhika',23,'Female'),('ABK0037',1,'Saurabh',22,'Male'),('ABK0038',1,'Saurabh',22,'Male'),('ABK0038',1,'aaa',22,'Male'),('ABK0038',1,'Saurabh Bhatia',22,'Male'),('ABK0039',1,'Saurabh',22,'Male'),('ABK0039',1,'Saurabh',22,'Male'),('ABK0039',1,'Saurabh',22,'Male'),('ABK0040',1,'Saurabh',22,'Male'),('ABK0040',1,'Saurabh',22,'Male'),('ABK0040',1,'Saurabh',22,'Male'),('ABK0041',1,'Saurabh',22,'Male'),('ABK0041',1,'Saurabh',22,'Male'),('ABK0041',1,'Saurabh Bhatia',22,'Male'),('ABK0042',1,'Saurabh',22,'Male'),('ABK0042',1,'Saurabh Bhatia',22,'Male'),('ABK0042',1,'Saurabh',22,'Male'),('ABK0043',1,'Saurabh',22,'Male'),('ABK0043',1,'aaa',22,'Male'),('ABK0043',1,'Saurabh Bhatia',22,'Male'),('ABK0044',1,'Saurabh',22,'Male'),('ABK0044',1,'Saurabh',22,'Male'),('ABK0044',1,'Saurabh Bhatia',22,'Male'),('ABK0045',1,'Saurabh',22,'Male'),('ABK0045',1,'aaa',22,'Male'),('ABK0045',1,'Saurabh Bhatia',22,'Male'),('ABK0046',1,'Saurabh',22,'Male'),('ABK0046',1,'aaa',22,'Male'),('ABK0046',1,'Saurabh Bhatia',22,'Male'),('ABK0047',1,'Saurabh',22,'Male'),('ABK0047',1,'aaa',22,'Male'),('ABK0047',1,'Saurabh Bhatia',22,'Male'),('ABK0048',1,'Saurabh12123',22,'Male'),('ABK0048',1,'aaa',22,'Male'),('ABK0048',1,'Saurabh Bhatia',22,'Male'),('ABK0049',1,'Saurabh',22,'Male'),('ABK0049',1,'Saurabh Bhatia',22,'Male'),('ABK0049',1,'Saurabh',22,'Male'),('ABK0050',1,'Saurabh',22,'Male'),('ABK0050',1,'Saurabh',22,'Male'),('ABK0050',1,'Saurabh',22,'Male'),('ABK0051',1,'Saurabh',22,'Male'),('ABK0051',1,'aaa',22,'Male'),('ABK0051',1,'Saurabh Bhatia',22,'Male'),('ABK0052',1,'Saurabh',22,'Male'),('ABK0053',1,'d',22,'Male'),('ABK0053',1,'dsd',22,'Male'),('ABK0054',2,'Saurabh',22,'Male'),('ABK0054',2,'Saurabh',22,'Male'),('ABK0054',2,'Saurabh Bhatia',22,'Male'),('ABK0055',2,'Saurabh',22,'Male'),('ABK0055',2,'Saurabh',22,'Male'),('ABK0055',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0057',2,'Saurabh',22,'Male'),('ABK0057',2,'Saurabh',22,'Male'),('ABK0057',2,'Saurabh',22,'Male'),('ABK001',2,'Saurabh',22,'Male'),('ABK001',2,'Saurabh',22,'Male'),('ABK001',2,'Saurabh',22,'Male'),('ABK002',2,'Saurabh',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK002',2,'Saurabh12123',22,'Male'),('ABK002',2,'d',22,'Male'),('ABK002',2,'d',22,'Male'),('ABK002',2,'Saurabh',22,'Male'),('ABK002',2,'Saurabh',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK002',2,'Saurabh Bhatia',22,'Male'),('ABK003',2,'anusha',22,'Female'),('ABK003',2,'avi',21,'Male'),('ABK003',2,'d',20,'Female'),('ABK004',2,'Saurabh',22,'Male'),('ABK005',2,'Saurabh',22,'Male'),('ABK005',2,'Ishant Aggarwal',22,'Male'),('ABK005',2,'Saurabh Bhatia',22,'Male'),('ABK006',2,'Saurabh',22,'Male'),('ABK006',2,'Ishant Aggarwal',22,'Male'),('ABK006',2,'Saurabh Bhatia',22,'Male'),('ABK007',2,'Saurabh',22,'Male'),('ABK007',2,'Ishant Aggarwal',22,'Male'),('ABK007',2,'Saurabh Bhatia',22,'Male'),('ABK008',2,'Saurabhs',22,'Male'),('ABK008',2,'Ishant',22,'Male'),('ABK008',2,'Ishant',22,'Male'),('ABK009',2,'Saurabh',22,'Male'),('ABK009',2,'Ishant',22,'Male'),('ABK009',2,'Ishant',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK009',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Ishant',22,'Male'),('ABK0010',2,'Ishant',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK0010',2,'Saurabh',22,'Male'),('ABK001',2,'Saurabh',22,'Male'),('ABK0011',2,'Saurabh',22,'Male'),('ABK0012',2,'Saurabh',22,'Male'),('ABK0013',2,'Saurabh',22,'Male'),('ABK0014',2,'Saurabh',22,'Male'),('ABK0014',2,'Ishant Aggarwal',22,'Male'),('ABK0015',2,'Saurabh',22,'Male'),('ABK0016',2,'Saurabh',22,'Male'),('ABK0017',2,'Saurabh',22,'Male'),('ABK0017',2,'Ishant Aggarwal',22,'Male'),('ABK0018',2,'Saurabh',22,'Male'),('ABK0018',2,'Ishant Aggarwal',22,'Male'),('ABK0018',2,'Saurabh Bhatia',22,'Male'),('ABK0019',2,'Saurabh',22,'Male'),('ABK0020',2,'Saurabh',22,'Male'),('ABK0021',2,'Saurabh',22,'Male'),('ABK0022',2,'Saurabh',22,'Male'),('ABK0022',2,'Ishant Aggarwal',22,'Male'),('ABK0023',2,'Saurabh',22,'Male'),('ABK0024',2,'Saurabh',22,'Male'),('ABK0025',2,'Saurabh',22,'Male'),('ABK0026',2,'Saurabh',22,'Male'),('ABK0027',2,'Saurabh',22,'Male'),('ABK0028',2,'Saurabh',22,'Male'),('ABK0029',2,'Saurabh',22,'Male'),('ABK0030',2,'Ishant',22,'Male'),('ABK0031',2,'Saurabh',22,'Male'),('ABK0032',2,'Saurabh',22,'Male'),('ABK0033',2,'Saurabh',22,'Male'),('ABK0034',2,'Saurabh',22,'Male'),('ABK0035',2,'Saurabh',22,'Male'),('ABK0036',2,'dffd34',22,'Male'),('ABK0037',2,'Saurabh234324',22,'Male'),('ABK0038',2,'Saurabh Bhatia',22,'Male'),('ABK0039',2,'Saurabh1213',22,'Male'),('ABK0040',2,'Saurabh1223',22,'Male'),('ABK0041',2,'Saurabh Bhatia',22,'Male'),('ABK0042',2,'s',22,'Male'),('ABK0043',2,'Saurabh',22,'Male'),('ABK0043',2,'Saurabh Bhatia',22,'Male'),('ABK0044',2,'Saurabh',22,'Male'),('ABK0044',2,'Saurabh Bhatia',22,'Male'),('ABK0045',2,'Saurabh',22,'Male'),('ABK0045',2,'Ishant',22,'Male'),('ABK0046',2,'Saurabh',22,'Male'),('ABK0046',2,'Saurabh Bhatia',22,'Male'),('ABK0047',2,'Saurabh',22,'Male'),('ABK0047',2,'Saurabh Bhatia',22,'Male'),('ABK0048',2,'Saurabh',22,'Male'),('ABK0049',2,'Saurabh',22,'Male'),('ABK0049',2,'Saurabh Bhatia',22,'Male'),('ABK0050',2,'Saurabh',22,'Male'),('ABK0050',2,'Saurabh Bhatia',22,'Male'),('ABK0051',2,'Saurabh',22,'Male'),('ABK0052',2,'Saurabh',22,'Male'),('ABK0053',2,'Saurabh',22,'Male'),('ABK0054',2,'Saurabh',22,'Male'),('ABK0054',2,'Saurabh',22,'Male'),('ABK0055',14,'Saurabh',22,'Male'),('ABK0055',14,'Ishant',22,'Male'),('ABK0055',14,'Saurabh Bhatia',22,'Male'),('ABK0055',14,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Ishant',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0056',2,'Saurabh',22,'Male'),('ABK0057',2,'Saurabh',22,'Male'),('ABK0058',2,'Saurabh',22,'Male'),('ABK0059',2,'Saurabh',22,'Male'),('ABK0060',2,'Saurabh',22,'Male'),('ABK0061',2,'Saurabh',22,'Male'),('ABK0062',2,'Saurabh',22,'Male'),('ABK0063',2,'Saurabh',22,'Male'),('ABK0064',2,'Saurabh',22,'Male'),('ABK0065',2,'Saurabh',22,'Male'),('ABK0066',2,'Saurabh',22,'Male'),('ABK0067',2,'Saurabh',22,'Male'),('ABK0068',2,'Saurabh',22,'Male'),('ABK0069',2,'Saurabh',22,'Male'),('ABK0070',2,'Saurabh',22,'Male');
/*!40000 ALTER TABLE `travelling_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'airline_reservation_system'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-03 10:23:01
