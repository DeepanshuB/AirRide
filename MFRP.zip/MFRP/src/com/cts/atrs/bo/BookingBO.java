/*
 * 
 */
package com.cts.atrs.bo;

import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Logger;

import com.cts.atrs.dao.BookFlightImplementDao;
import com.cts.atrs.exceptions.ApplicationException;
import com.cts.atrs.exceptions.DatabaseOperationException;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.PassengerModel;



/**
 * The Class BookingBO.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class BookingBO 
{
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("BookingBO.class");


	/**
	 * Checks if is valid book data.
	 *
	 * @param bookFlightModel the book flight model
	 * @param date_booking the date_booking
	 * @return true, if is valid book data
	 */
	public boolean isValidBookData(final BookFlightModel bookFlightModel, final String date_booking) 
	{
		boolean result = false ;
		try 
		{
			result = new BookFlightImplementDao().saveTempBookingData(bookFlightModel, date_booking);
		} 
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return result ;
	}

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId()
	{
		String bookingId = null;
		try 
		{
			bookingId = new BookFlightImplementDao().generateBookingId();
		}
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return bookingId;
	}

	/**
	 * Checks if is seat available.
	 *
	 * @param bookFlightModel the book flight model
	 * @return true, if is seat available
	 */
	public boolean isSeatAvailable(final BookFlightModel bookFlightModel) 
	{
		int availableSeats = 0 ;
		boolean result = false ;
		try
		{

			availableSeats = new BookFlightImplementDao().getSeatAvailability(bookFlightModel);
			if(bookFlightModel.getNumberOfPassenger() <= availableSeats)
			{
				result = true ;
			}
		} 
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return result ;
	}

	/**
	 * Checks if is valid confirmed book data.
	 *
	 * @param bookFlightModel the book flight model
	 * @param customerId the customer id
	 * @return true, if is valid confirmed book data
	 * @throws SQLException the sQL exception
	 */
	public boolean isValidConfirmedBookData(final BookFlightModel bookFlightModel, final int customerId) throws SQLException 
	{
		boolean saveBookDataFlag = false ;
		try
		{
			saveBookDataFlag = new BookFlightImplementDao().saveConfirmBookingData(bookFlightModel, customerId);
		} 
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);

		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}

		return saveBookDataFlag ;
	}

	/**
	 * Checks if is seats updated.
	 *
	 * @param bookFlightModel the book flight model
	 * @return true, if is seats updated
	 */
	public boolean isSeatsUpdated(final BookFlightModel bookFlightModel)
	{
		boolean result = false ;
		Integer availableSeats = 0 ;
		try 
		{
			availableSeats =  new BookFlightImplementDao().getSeatAvailability(bookFlightModel);
			result = new BookFlightImplementDao().updateSeatsAvailability(bookFlightModel, availableSeats);
		}
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return result ;
	}

	/**
	 * Checks if is flight search result deleted.
	 *
	 * @return true, if is flight search result deleted
	 */
	public boolean isFlightSearchResultDeleted() 
	{
		boolean answer = false ;
		try 
		{
			answer =  new BookFlightImplementDao().removeFlightSearchResult();
		} 
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return answer;
	}

	/**
	 * Checks if is passenger details saved.
	 *
	 * @param passengerList the passenger list
	 * @return true, if is passenger details saved
	 */
	public boolean isPassengerDetailsSaved(final List<PassengerModel> passengerList) 
	{
		boolean answer = false ;
		try 
		{
			answer = new BookFlightImplementDao().addPassengerDetails(passengerList);
		} 
		catch (DatabaseOperationException e) 
		{
			LOG.error(e);
		}
		catch (ApplicationException e) 
		{
			LOG.error(e);
		}
		return answer;
	}

}
