package com.cts.atrs.bo;
import org.junit.Test;
import junit.framework.TestCase;
import java.util.ArrayList;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.PassengerModel;

import java.util.List;

/**
 * This class contains one test method for BookingBO class.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

//TODO Add Junit jar in build path.
//TODO Modify input and output data if needed.


public class BookingBOTest extends TestCase {


	/**
	 * Test is seat available.
	 */
	@Test //public boolean isSeatAvailable(BookFlightModel)
	public void testIsSeatAvailable(){
		BookingBO e0Obj = new BookingBO();
		BookFlightModel e0Arg0 = new BookFlightModel();
		e0Arg0.setCustomerName("lCu5SgnGD");
		e0Arg0.setAirlineName("c1Uv6iUv5c");
		e0Arg0.setLeavingFrom("0flAE6t7K");
		e0Arg0.setNumberOfPassenger(41);
		e0Arg0.setDepartureTime("biejsLPqtln6dZj4hw");
		e0Arg0.setBookingDate("mFxhXsln2xGA70lrCfb");
		e0Arg0.setTotalPrice(63);
		e0Arg0.setDateOfJourney("jocrg5cA");
		e0Arg0.setSubTotalPrice(12);
		e0Arg0.setBookingId("hwck0pPW5Kea4");
		e0Arg0.setGoingTo("sUm2v5cAPoXtIQABO");
		e0Arg0.setPrice(53);
		e0Arg0.setDiscount(-14);
		e0Arg0.setFlightId("vPwoQJcsTm8ik");


		boolean e0 = e0Obj.isSeatAvailable(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals( false, e0);
	}


	/**
	 * Test is valid book data.
	 */
	@Test //public boolean isValidBookData(BookFlightModel,String)
	public void testIsValidBookData(){
		BookingBO e0Obj = new BookingBO();
		BookFlightModel e0Arg0 = new BookFlightModel();
		e0Arg0.setCustomerName("gWNWbeaVgpVAkr");
		e0Arg0.setAirlineName("qtesRtiXPiX9OKTaGYS");
		e0Arg0.setLeavingFrom("RQl0QK8u26");
		e0Arg0.setNumberOfPassenger(-71);
		e0Arg0.setDepartureTime("TbPDGQ");
		e0Arg0.setBookingDate("AEaowafKz");
		e0Arg0.setTotalPrice(49);
		e0Arg0.setDateOfJourney("igg6U7jCOr");
		e0Arg0.setSubTotalPrice(20);
		e0Arg0.setBookingId("Mn3QV0FDHyPFHs6d1");
		e0Arg0.setGoingTo("3QacbAEdwH9Vo");
		e0Arg0.setPrice(59);
		e0Arg0.setDiscount(50);
		e0Arg0.setFlightId("o2jkUUbLk3utGtmOvf");


		boolean e0 = e0Obj.isValidBookData(e0Arg0,"nFDsm");
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(false,e0);
	}


	/**
	 * Test is seats updated.
	 */
	@Test //public boolean isSeatsUpdated(BookFlightModel)
	public void testIsSeatsUpdated(){
		BookingBO e0Obj = new BookingBO();
		BookFlightModel e0Arg0 = new BookFlightModel();
		e0Arg0.setCustomerName("FMPpCHspK3");
		e0Arg0.setAirlineName("b00qcwE5PxkQck3O3Y4");
		e0Arg0.setLeavingFrom("eWYK02bqJst92C");
		e0Arg0.setNumberOfPassenger(-18);
		e0Arg0.setDepartureTime("mZDT2CmihULUqJ");
		e0Arg0.setBookingDate("CU");
		e0Arg0.setTotalPrice(-36);
		e0Arg0.setDateOfJourney("bLIfr3VrTs0ES5Maxq");
		e0Arg0.setSubTotalPrice(52);
		e0Arg0.setBookingId("2GxkfQ");
		e0Arg0.setGoingTo("vxnrekvRU");
		e0Arg0.setPrice(9);
		e0Arg0.setDiscount(-53);
		e0Arg0.setFlightId("YH6VkmJDmg");


		boolean e0 = e0Obj.isSeatsUpdated(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(true,e0);
	}


	/**
	 * Test is flight search result deleted.
	 */
	@Test //public boolean isFlightSearchResultDeleted()
	public void testIsFlightSearchResultDeleted(){
		BookingBO e0Obj = new BookingBO();
		boolean e0 = e0Obj.isFlightSearchResultDeleted();
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(true,e0);
	}


	/**
	 * Test is passenger details saved.
	 */
	@Test //public boolean isPassengerDetailsSaved(List<PassengerModel>)
	public void testIsPassengerDetailsSaved(){
		BookingBO e0Obj = new BookingBO();
		PassengerModel e0Arg0Com0 = new PassengerModel();
		e0Arg0Com0.setCustomerID(33);
		e0Arg0Com0.setPassengerName("t6brXXmlJZHV9IPd");
		e0Arg0Com0.setPassengerAge(34);
		e0Arg0Com0.setPassengerGender("UQnaH");
		e0Arg0Com0.setBookingId("nojjNqdN9kaBKnCL8Gb");


		List<PassengerModel> e0Arg0 = new ArrayList<PassengerModel>();
		e0Arg0.add(e0Arg0Com0);
		boolean e0 = e0Obj.isPassengerDetailsSaved(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(false, e0);
	}


	/**
	 * Test is valid confirmed book data.
	 */
	@Test //public boolean isValidConfirmedBookData(BookFlightModel,int)
	public void testIsValidConfirmedBookData(){
		BookingBO e0Obj = new BookingBO();
		BookFlightModel e0Arg0 = new BookFlightModel();
		e0Arg0.setCustomerName("mwB8w61bfn5");
		e0Arg0.setAirlineName("eAeMPeAZhDA8jibd");
		e0Arg0.setLeavingFrom("asxTQCq");
		e0Arg0.setNumberOfPassenger(-67);
		e0Arg0.setDepartureTime("cFG");
		e0Arg0.setBookingDate("15bvvQqZKaGsXix");
		e0Arg0.setTotalPrice(15);
		e0Arg0.setDateOfJourney("5dfoNbfr3fAf");
		e0Arg0.setSubTotalPrice(98);
		e0Arg0.setBookingId("LBA05MGy2momOSe");
		e0Arg0.setGoingTo("mDxWQtzzAmBdaUBUk7");
		e0Arg0.setPrice(-63);
		e0Arg0.setDiscount(-15);
		e0Arg0.setFlightId("");


		try{
			boolean e0 = e0Obj.isValidConfirmedBookData(e0Arg0,72);
			//TODO Based on your need, provide necessary assertion condition
			assertEquals(false,e0);
		}catch(Exception e){
			fail();
		}
	}


}
