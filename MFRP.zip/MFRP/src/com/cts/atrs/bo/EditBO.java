/*
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 * 
 */


package com.cts.atrs.bo;

import org.apache.log4j.Logger;

import com.cts.atrs.dao.EditDAO;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class EditBO.
 * 
 */
public class EditBO {
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("EditBO.class");
	
	/**
	 * Update user details.
	 * Takes updated values from the user and sends these details as usermodel to EditDao class
	 * @param usermodel the usermodel
	 * @return true, if successful
	 */
	public boolean updateUserDetails(final UserDetailsModel usermodel) {

		final EditDAO editdao = new EditDAO(); 

		boolean editvalid =false;
			try 
			{
				editvalid = editdao.updateUserDetails(usermodel);
			}
			catch (Exception e)
			{
				LOG.error(e);
				editvalid =false;
			}
			return editvalid;

		}
}
	
