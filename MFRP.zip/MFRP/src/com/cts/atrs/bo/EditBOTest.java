package com.cts.atrs.bo;
import org.junit.Test;
import junit.framework.TestCase;
import com.cts.atrs.model.UserDetailsModel;
import com.cts.atrs.bo.EditBO;


/** This class contains one testXXXX method per XXXXX method in source class
* @author 
**/
//TODO Add Junit jar in build path.
//TODO Modify input and output data if needed.


public class EditBOTest extends TestCase {
	

	@Test //public boolean updateUserDetails(UserDetailsModel)
	public void testUpdateUserDetails(){
		EditBO e0Obj = new EditBO();
		UserDetailsModel e0Arg0 = new UserDetailsModel();
		e0Arg0.setPassword("od4qZWkbH5");
		e0Arg0.setName("aeoWpnDDokQ");
		e0Arg0.setFlag(false);
		e0Arg0.setAddress("V");
		e0Arg0.setSsnType("hINgm");
		e0Arg0.setSsnNumber("vdPBjG");
		e0Arg0.setGender("aDYwODj1Uc0Q3Tc");
		e0Arg0.setCid(-85);
		e0Arg0.setDob("Ee");
		e0Arg0.setEmail("mYkx0LxHaMQrfHGgS");
		e0Arg0.setPhone("3U");
		

		boolean e0 = e0Obj.updateUserDetails(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(false,e0);
	}

}
