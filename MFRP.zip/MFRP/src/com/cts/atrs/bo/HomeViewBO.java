/*
 * 
 */
package com.cts.atrs.bo;

import java.util.List;

import com.cts.atrs.dao.HomeViewDao;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class HomeViewBO.
 */
public class HomeViewBO {

/** The homedao. */
private transient HomeViewDao homedao ;
	
	/**
	 * Gets the details.
	 *
	 * @param emailid the emailid
	 * @return the details
	 */
	public List<UserDetailsModel> getDetails(final String emailid) {
		return getHomedao().getDetails(emailid);
		
		
	}
	
	/**
	 * Gets the homedao.
	 *
	 * @return the homedao
	 */
	public HomeViewDao getHomedao() {
		if(homedao == null)
		{
			homedao = new HomeViewDao();
		}
		return homedao;
	}

	

}
