/*
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 * 
 */
package com.cts.atrs.bo;

import org.apache.log4j.Logger;

import com.cts.atrs.dao.LoginDAO;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class LoginBO.
 * 
 */
public class LoginBO {

	/** The logindao. */
	private static transient LoginDAO logindao = new LoginDAO(); 
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("LoginBO.class");
	
	/**
	 * Validate login bo.
	 * This method takes input from BaseControllerServlet1 class using POJO class model and send it to LoginDao class
	 * @param obj the obj
	 * @return true, if successful
	 */
	public boolean validateLoginBo (final UserDetailsModel obj)
	{
		boolean loginvalid =false;
		logindao = new LoginDAO();
		try 
		{
			loginvalid = logindao.validateLoginDao(obj);
		}
		catch (Exception e)
		{
		LOG.error(e);
			loginvalid =false;
		}
		return loginvalid;

	}
}
