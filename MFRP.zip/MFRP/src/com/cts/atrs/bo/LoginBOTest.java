package com.cts.atrs.bo;

import org.junit.Test;
import junit.framework.TestCase;
import com.cts.atrs.model.UserDetailsModel;
import com.cts.atrs.bo.LoginBO;


/** This class contains one testXXXX method per XXXXX method in source class
* @author 
**/
//TODO Add Junit jar in build path.
//TODO Modify input and output data if needed.


public class LoginBOTest extends TestCase {
	

	@Test //public boolean validateLoginBo(UserDetailsModel)
	public void testValidateLoginBo(){
		LoginBO e0Obj = new LoginBO();
		UserDetailsModel e0Arg0 = new UserDetailsModel();
		e0Arg0.setPassword("krXTUGEoBK2qmQerWe");
		e0Arg0.setName("DG3WESiZNs6puSS7y");
		e0Arg0.setFlag(false);
		e0Arg0.setAddress("IxT9uiCrrSlFU");
		e0Arg0.setSsnType("HkGc5calY");
		e0Arg0.setSsnNumber("DbGZelxrjbWnGW");
		e0Arg0.setGender("CyrDWKJAOKExzdv");
		e0Arg0.setCid(-88);
		e0Arg0.setDob("vh");
		e0Arg0.setEmail("rSVT5qHou21XdZRe");
		e0Arg0.setPhone("bgZBxo");
		

		boolean e0 = e0Obj.validateLoginBo(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(false,e0);
	}
	

}
