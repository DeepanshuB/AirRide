/*
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 * 
 */
package com.cts.atrs.bo;

import org.apache.log4j.Logger;

import com.cts.atrs.dao.RegisterDAO;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class RegisterBO.
 *
 */
public class RegisterBO {
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("RegisterBO.class");

	/**
	 * Sets the user details.
	 * This method takes input from userRegistration form as usermodel Object and sends it to RegisterDao class
	 * @param usermodel the usermodel
	 * @return true, if successful
	 */
	public boolean setUserDetails(final UserDetailsModel usermodel) {
		
		RegisterDAO registerdao = new RegisterDAO(); 
		
		boolean registervalid =false;
			registerdao = new RegisterDAO();
			try 
			{
				registervalid = registerdao.insertRegisterDetails(usermodel);
			}
			catch (Exception e)
			{
				LOG.error(e);
				registervalid =false;
			}
			return registervalid;

		}
	

}
