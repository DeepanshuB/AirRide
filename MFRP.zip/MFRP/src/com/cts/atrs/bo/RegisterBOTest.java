package com.cts.atrs.bo;
import org.junit.Test;
import junit.framework.TestCase;
import com.cts.atrs.bo.RegisterBO;
import com.cts.atrs.model.UserDetailsModel;


/** This class contains one testXXXX method per XXXXX method in source class
* @author 
**/
//TODO Add Junit jar in build path.
//TODO Modify input and output data if needed.


public class RegisterBOTest extends TestCase {
	

	@Test //public boolean setUserDetails(UserDetailsModel)
	public void testSetUserDetails(){
		RegisterBO e0Obj = new RegisterBO();
		UserDetailsModel e0Arg0 = new UserDetailsModel();
		e0Arg0.setPassword("V");
		e0Arg0.setName("1hy");
		e0Arg0.setFlag(false);
		e0Arg0.setAddress("HTFdCVT");
		e0Arg0.setSsnType("cTetm1aX9dxYuF8");
		e0Arg0.setSsnNumber("p8GfuXjldMUo7mJYCEd");
		e0Arg0.setGender("pbiwEPGY");
		e0Arg0.setCid(-10);
		e0Arg0.setDob("m7XJY");
		e0Arg0.setEmail("hz49TC");
		e0Arg0.setPhone("rgkEm1iKD");
		

		boolean e0 = e0Obj.setUserDetails(e0Arg0);
		//TODO Based on your need, provide necessary assertion condition
		assertEquals(false,e0);
	}
	

}
