/*
 * 
 */
package com.cts.atrs.bo;

import java.util.List;

import com.cts.atrs.dao.SearchFlightDAO;
import com.cts.atrs.model.FlightModel;

/**
 * The Class SearchBo.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public class SearchBO {
	
	/**
	 * Search result.
	 *
	 * @param flightModel the flight model
	 * @return the list
	 */
	public List<FlightModel> searchResult(final FlightModel flightModel){
		return new SearchFlightDAO().searchFlight(flightModel);
	}

}
