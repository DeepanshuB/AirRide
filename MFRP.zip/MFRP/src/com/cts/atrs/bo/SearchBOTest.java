package com.cts.atrs.bo;
import static org.junit.Assert.*;
import org.junit.Test;
import junit.framework.TestCase;
import com.cts.atrs.model.FlightModel;
import com.cts.atrs.bo.SearchBO;

import java.util.List;


import static org.hamcrest.CoreMatchers.*;


/**
 * The Class contains test of SearchDao Flight.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */


public class SearchBOTest extends TestCase {


	@Test //public List<FlightModel> searchResult(FlightModel)
	public void testSearchResult() {
		SearchBO e0Obj = new SearchBO();
		FlightModel e0Arg0 = new FlightModel();
		e0Arg0.setFare(-4);
		e0Arg0.setDest("Mumbai");
		e0Arg0.setSrc("Chennai");
		e0Arg0.setDeptDate("31/JUN/2018");
		e0Arg0.setNoOfSeats(53);
		e0Arg0.setFlightNo("F20");
		e0Arg0.setDepartTime("16:30");
		e0Arg0.setAirlineName("Indigo");

		try
		{
			List<FlightModel> e0 = e0Obj.searchResult(e0Arg0);
			//TODO Based on your need, provide necessary assertion condition
			assertThat(e0.size(),is(0));
		}
		catch(Exception e){
			fail();
		}
	}


}
