package com.cts.atrs.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class BusinessLogicErrors.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
final public class BusinessLogicErrors {

	/**
	 * Instantiates a new business logic errors.
	 */
	private BusinessLogicErrors() {

	}

	/** This constant MANDATORY_FIELDS_ERROR carries the error message that  is to be displayed when customer name doesn't follow business conditions. */
	public static final String MANDATORY_ERROR = "All fields are mandatory: Enter all the fields";

	/** This constant USER_NAME_ERROR carries the error message that is to be displayed when vendor name doesn't follow business conditions. */
	public static final String USER_NAME_ERROR = "Name should not contain special characters, numbers & should also not exceed 45 characters";

	/** This constant EMAIL_ID_ERROR carries the error message that is to be displayed when email doesn't follow business conditions. */
	public static final String EMAIL_ID_ERROR = "enter email in user_name@domain_name.com format";


	/** The Constant EMAIL_EXISTS. */
	public static final String EMAIL_EXISTS = "This Email id is already used by another user, Please enter valid email id";


	/** The Constant PASSWORD_ERROR. */
	public static final String PASSWORD_ERROR = "Password must have at least one special character";
	/** This constant PHONE_NO_ERROR carries the error message that is to be displayed when phone number doesn't follow business conditions. */


	public static final String DOB_FORMAT_ERROR = "Characters not allowed in date : DOB should be in dd-mm-yyyy format";


	/** The Constant PHONE_NO_ERROR. */
	public static final String PHONE_NO_ERROR = "Phone number should contain 10 digits";

	/** This constant VALID_ID_ERROR carries the error message that is to be displayed when the entered id document for proof of the customer doesn't follow business conditions. */
	public static final String ID_PROOF_ERROR = "Enter a id proof  type out of following :-for voter id enter gmv,for driving license enter dl,for pan card enter pan, for passport enter pass, for social security number enter ssn.";	


	/** The Constant GENDER_ERROR. */
	public static final String GENDER_ERROR = "Please enter valid input";


	/** The Constant SSN_TYPE_ERROR. */
	public static final String SSN_TYPE_ERROR = "Please enter valid choice ";

	/** The Constant INPUT_ERROR. */
	public static final String  INPUT_ERROR = "Entered choice should be of integer type";


}




