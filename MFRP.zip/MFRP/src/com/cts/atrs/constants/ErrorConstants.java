package com.cts.atrs.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class ErrorConstants.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
final public class ErrorConstants
{


	/**
	 * Instantiates a new error constants.
	 */
	private ErrorConstants() {

	}

	/** constant carrying class not found exception. */
	public static final String CLASS_NOT_FOUND = "May Be Driver Class Not Found Exception";

	/** constant carrying message to be displayed whenever an exception arises while closing resources. */
	public static final String RESOURCES_ERR = "Signals that an I/O exception of some sort has occurred.";

	/** Constant variable carrying message that is to be displayed when there is an exception in executing the SQL query. */
	public static final String QUERY_ERROR = "SQL query could not be executed";
	
	/** Constant variable carrying message that is to be displayed when there is an exception in executing the SQL query. */
	public static final String INSERTION_ERROR = "Invalid Data Entered: Database Insertion not possible";

	/** Constant variable carrying message that is to be displayed when there is an exception in executing the SQL query. */
	public static final String NULL_ERROR = "there are null values for object";

	/** * message for customer registration fail case. */
	public static final String CUST_REG_ERROR = "Customer registration failed";

	/** * message for vendor registration fail case. */
	public static final String LOGIN_ERROR = "Failed attempt to login : Entered Wrong Credentials";

	/** This constant INPUT_MISMATCH_ERROR carries the error message that is to be displayed when the given inputs doen't follow business conditions. */
	public static final String INPUT_ERROR = "Enter valid input as per the datatype.";

}