package com.cts.atrs.constants;


// TODO: Auto-generated Javadoc
/**
 * The Class QueryConstants.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class QueryConstants {

	/** The Constant GET_EMAILS. */
	public static final String GET_EMAILS = "select email from customer_info";

	/** The Constant GET_PASSWORDS_QUERY. */
	public static final String GET_PASSWORD = "select password from customer_info";

	/** The Constant GET_LOGIN_CREDENTIALS. */
	public static final String USER_AUTH = "select email,password from customer_info";

	/** The Constant INSERT_NEW_USER_DETAILS. */
	public static final String INSERT_USER = "insert into customer_info(cname,email,password,dob,address,phone,gender,ssn_type,ssn_no) values(?,?,?,?,?,?,?,?,?)";

	/** The Constant GET_ALL_DETAILS. */
	public static final String GET_ALL_DETAILS = "select * from customer_info where email=? and password=?";

	/** The Constant GET_SSN_TYPES. */
	public static final String GET_SSN_TYPES = "select * from ssn_master";

	/** The Constant UPDATE_USER_DETAILS. */
	public static final String UPDATE_USER=" update customer_info set cname=?,password=?,dob=?,address=?,phone=? where email=?";

	/*Booking Queries */

	/** The Constant for generating booking Id. */
	public static final String GENERATE_ID = "SELECT booking_id FROM booking_info order by booking_id desc LIMIT 1;";

	/** The Constant for getting seats of flight. */
	public static final String GET_SEATS = "select ava_seats from seats_available where f_no=? ";

	/** The Constant for updating seats after booking. */
	public static final String UPDATE_SEATS = "update seats_available set ava_seats=? where f_no=? and dept_date=?";

	/** The Constant for deleting data from temporary table. */
	public static final String EMPTY_FLIGHT_DATA = "delete from search_temp_master";

	/** The Constant for inserting booking information. */
	public static final String INSERT_BOOK_INFO = "insert into booking_info values (?,?,?,?,?,?)";

	/** The Constant for inserting temporary invoice. */
	public static final String SAVE_TEMP_DATA = "insert into invoice_temp_master values (?,?,?,?,?,?,?,?)";

	/** The Constant for adding passenger details. */
	public static final String PASSENGER_DETAIL = "insert into travelling_details values(?,?,?,?,?)";

	/*Search Result Flight Queries */

	/** The Constant FLIGHT_LIST. */
	public static final String FLIGHT_LIST = "select f_no, a_name , src, depart_time, dest, fare, dept_date, no_of_seats from search_temp_master";

	/** The Constant DEL_FLIGHT_DATA. */
	public static final String DEL_FLIGHT_DATA = "delete from search_temp_master";

	/*Searching Queries
	 */
	/** The Constant SEARCH_LOCATION. */
	public final static String SEARCH_LOCATION = "select location_name from location_master"; 

	/** The Constant SEARCH_LOC_DB. */
	public static final String SEARCH_LOC_DB = "select location_id from location_master where location_name = ?";

	/** The Constant SEARCH_FLIGHT. */
	public final static String SEARCH_FLIGHT = "SELECT b.f_no,c.a_name,b.src,b.depart_time,b.dest,b.fare FROM seats_available a inner join flight_master b on a.f_no=b.f_no inner join airlines_master c on b.a_id=c.a_id where b.src = ? and b.dest = ? and a.dept_date = ? and  b.depart_time= ? and a.ava_seats >= ?;";

	/** The Constant STORE_SEARCH_DATA. */
	public static final String STORE_SEARCH_DATA = "insert into search_temp_master values(?,?,?,?,?,?,?,?)";

	/* Cancel Queries */

	//public static final String GET_BOOKED_FLIGHTS="select bd.booking_id, bd.airline_name, bd.leaving_from, bd.going_to,sa.dept_date,bd.departure_time,bi.price from booking_detail bd inner join booking_info bi on bi.booking_id=bd.booking_id inner join flight_master fm on fm.f_no=bi.f_no inner join seats_available sa on fm.f_no=sa.f_no where bi.cid=?";
	/** The Constant GET_BOOKED_FLIGHTS. */
	public static final String GET_FLIGHTS = "select bi.booking_id,a.a_name,sa.dept_date,f.depart_time,f.src,f.dest,bi.price,bi.seat_book from booking_info bi inner join flight_master f  on bi.f_no = f.f_no inner join airlines_master a on f.a_id = a.a_id inner join seats_available sa on f.f_no = sa.f_no where bi.cid=?";

	/** The Constant GET_PRICE. */
	public static final String GET_PRICE="select sa.dept_date , bi.price, f.depart_time from booking_info bi inner join flight_master f on bi.f_no = f.f_no inner join seats_available sa on sa.f_no = bi.f_no where booking_id = ? and bi.cid = ?";

	/** The Constant GET_HISTORY. */
	public static final String GET_HISTORY= "Select * from  Cancel_History where Cid = ?";

	/** The Constant SAVE_HISTORY. */
	public static final String SAVE_HISTORY="INSERT INTO  Cancel_History  ( Booking_id ,  Cid ,  Total ,  charge ,  Refund, cancel_tax) VALUES (?, ?, ?, ?, ?,?)";

	/** The Constant DELETE_BOOKING_INFO. */
	public static final String DELETE_BOOKING = "delete from booking_info where booking_id=?";
	//public static final String DELETE_BOOKING_DETAIL="delete from booking_detail where booking_id= ?";
	/** The Constant UPDATE_SEATS_CANCEL. */
	public static final String UPDATE_CANCEL = "update seats_available set ava_seats=? where f_no=?";

	/** The Constant SELECT_BOOKING_INFO. */
	public static final String GET_BOOK_INFO= "select seat_book,f_no from booking_info where booking_id=?";

}
