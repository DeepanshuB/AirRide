package com.cts.atrs.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class RegexConstants.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class RegexConstants 
{
	
	/** The Constant VALIDATE_NAME. */
	public static final String VALIDATE_NAME = "([a-zA-Z]+ +)*[a-zA-Z]+";
	 
 	/** The Constant VALIDATE_AGE. */
 	public static final String VALIDATE_AGE="[1-9]|[1-9][0-9]|[1-9][0-9][0-9]";
}
