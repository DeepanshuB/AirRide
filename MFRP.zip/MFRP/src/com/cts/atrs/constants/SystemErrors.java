package com.cts.atrs.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class SystemErrors.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class SystemErrors {



	/** The Constant CONEECTION_ERROR. */
	
	/** The Constant CONNECTION_ERROR. */
	public static final String CONNECTION_ERROR = "Access denied :Could not connect to database, check database username and password";

}
