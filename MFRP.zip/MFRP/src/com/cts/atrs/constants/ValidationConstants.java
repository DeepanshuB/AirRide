package com.cts.atrs.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class ValidationConstants.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class ValidationConstants {

	/** The Constant VALIDATE_NAME. */
	public static final String VALIDATE_NAME = "([a-zA-Z]+ +)*[a-zA-Z]+";
	
	/** The Constant VALIDATE_EMAIL. */
	public static final String VALIDATE_EMAIL ="[a-zA-Z0-9\\.\\_]+@[a-zA-Z0-9]+\\.[a-zA-Z0-9]{3}|[a-zA-Z0-9\\.]+@[a-zA-Z0-9\\_\\.]+\\.[a-zA-Z0-9]{2}+\\.[a-zA-Z0-9]{2}|[a-zA-Z0-9\\.]+@[a-zA-Z0-9]+\\.[a-zA-Z]{2}+\\.[a-zA-Z0-9]{2}"; 
	
	/** The Constant VALIDATE_REGISTERING_PASSWORD. */
	public static final String VALID_PASSWORD = "^.*(?=.*?[#?!@$%^&*-]).*$";

}
