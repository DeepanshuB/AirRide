/*
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 * 
 */
package com.cts.atrs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.atrs.bo.EditBO;
import com.cts.atrs.bo.HomeViewBO;
import com.cts.atrs.bo.LoginBO;
import com.cts.atrs.bo.RegisterBO;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * Servlet implementation class BaseControllerServlet1.
 * This servlet class controls the flow of AirLine reservation system
 */
public class BaseControllerServlet1 extends HttpServlet {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 963L;

	/** The homebo. @see HttpServlet#HttpServlet() */
	private transient HomeViewBO homebo;

	/**
	 * Gets the homebo.
	 *
	 * @return the homebo
	 */
	public HomeViewBO getHomebo() {
		if(homebo==null){
			homebo=new HomeViewBO();
		}
		return homebo;
	}

	/**
	 * Instantiates a new base controller servlet1.
	 */
	public BaseControllerServlet1() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		final String action=request.getParameter("action");
		final HttpSession sess=request.getSession();
		final String emailid=(String)sess.getAttribute("usermodel");
		if(sess.isNew()){
			response.sendRedirect("/index.jsp");


		}
		else 
		{
			if(action.equals("profile"))
			{
				final List<UserDetailsModel> list=getHomebo().getDetails(emailid);
				request.setAttribute("ulist", list);
				final RequestDispatcher rdisp=request.getRequestDispatcher("/viewdetails.jsp");
				rdisp.forward(request, response);
			}
			else if(action.equals("edit"))
			{
				final List<UserDetailsModel> list=getHomebo().getDetails(emailid);
				request.setAttribute("ulist", list);
				final RequestDispatcher rdisp=request.getRequestDispatcher("/editdetails.jsp");
				rdisp.forward(request, response);
			}

		}

	}

	/** The loginbo. @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response) */

	private transient LoginBO loginbo;

	/**
	 * Gets the loginbo.
	 *
	 * @return the loginbo
	 */
	public LoginBO getLoginbo()
	{
		if(loginbo==null)
		{
			loginbo=new LoginBO();
		}
		return loginbo;
	}

	/** The registerbo. */
	private transient RegisterBO registerbo;

	/**
	 * Gets the registerbo.
	 *
	 * @return the registerbo
	 */
	public RegisterBO getRegisterbo()
	{
		if(registerbo==null)
		{
			registerbo = new RegisterBO();
		}
		return registerbo;
	}

	/** The editbo. */
	private transient EditBO editbo;

	/**
	 * Gets the editbo.
	 *
	 * @return the editbo
	 */
	public EditBO getEditbo()
	{
		if(editbo==null)
		{
			editbo = new EditBO();
		}
		return editbo;
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//	response.setContentType("text/html");
		//	PrintWriter out = response.getWriter();


		final String action = request.getParameter("action");



		// Login Module

		if("Login".equals(action)){

			final String email = request.getParameter("email");
			final String password = request.getParameter("password");

			UserDetailsModel usermodel = new UserDetailsModel();

			usermodel.setEmail(email);
			usermodel.setPassword(password);
			boolean bool = false;

			try {
				bool = getLoginbo().validateLoginBo(usermodel);
				//	System.out.println(bool);
			} catch (Exception e) {
				// TODO Auto-generated catch block

				e.printStackTrace();
			}
			if(bool==true){
				final HttpSession sess=request.getSession();
				final List<UserDetailsModel> list=getHomebo().getDetails(email);
				usermodel = list.get(0);
				sess.setAttribute("usermodel",email);
				sess.setAttribute("userName",usermodel.getName());
				sess.setAttribute("customerId",String.valueOf(usermodel.getCid()));
				sess.setAttribute("userLoggedOn",true);
				RequestDispatcher rdisp=request.getRequestDispatcher("/searchflight.jsp");
				rdisp.forward(request, response);
			}
			else {
				response.setContentType("text/html");
				request.setAttribute("errorMess", "The email or password you entered is incorrect.");
				final RequestDispatcher rdisp=request.getRequestDispatcher("/index.jsp");
				rdisp.include(request, response);
			}
		}

		// Registration Module

		else if("registration".equals(action))
		{


			final String cname = request.getParameter("cname");
			final String email = request.getParameter("email");
			final String password = request.getParameter("password");
			final String dob = request.getParameter("dob");
			final String address = request.getParameter("address");
			final String phone = request.getParameter("phone");
			final String gender = request.getParameter("gender");
			final String ssn_type = request.getParameter("ssn_type");
			final String ssn_no = request.getParameter("ssn_no");


			final UserDetailsModel usermodel = new UserDetailsModel();
			usermodel.setName(cname);
			usermodel.setEmail(email);
			usermodel.setPassword(password);
			usermodel.setAddress(address);
			usermodel.setDob(dob);
			usermodel.setPhone(phone);
			usermodel.setGender(gender);
			usermodel.setSsnType(ssn_type);
			usermodel.setSsnNumber(ssn_no);

			boolean bool = false;

			try {
				bool = getRegisterbo().setUserDetails(usermodel);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(bool==true){

				final RequestDispatcher rdisp=request.getRequestDispatcher("/thankyou.jsp");
				rdisp.forward(request, response);
			}
			else {
				response.setContentType("text/html");
				request.setAttribute("errorMess", "Email already exists..Registration Failed... Please register again");
				final RequestDispatcher rdisp=request.getRequestDispatcher("/Register.jsp");
				rdisp.include(request, response);
			}
		}

		// Edit Module

		else if("edit".equals(action))
		{


			final String cname = request.getParameter("cname");
			final String email = request.getParameter("email");
			final String password = request.getParameter("password");
			final String dob = request.getParameter("dob");
			final String address = request.getParameter("address");
			final String phone = request.getParameter("phone");

			final String gender = request.getParameter("gender");
			final String ssn_type = request.getParameter("ssn_type");
			final String ssn_no = request.getParameter("ssn_no");

			final UserDetailsModel usermodel = new UserDetailsModel();
			usermodel.setName(cname);
			usermodel.setEmail(email);
			usermodel.setPassword(password);
			usermodel.setAddress(address);
			usermodel.setDob(dob);
			usermodel.setPhone(phone);
			usermodel.setGender(gender);
			usermodel.setSsnType(ssn_type);
			usermodel.setSsnNumber(ssn_no);

			boolean bool = false;

			try {
				bool = getEditbo().updateUserDetails(usermodel);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(bool==true){
				response.setContentType("text/html");
				request.setAttribute("errorMess", "Updation Successful.. Redirecting Please wait.");

				final RequestDispatcher rdisp=request.getRequestDispatcher("/searchflight.jsp");
				rdisp.forward(request, response);
			}
			else {
				response.setContentType("text/html");
				request.setAttribute("errorMess", "Updation Failed... Please register again");
				final RequestDispatcher rdisp=request.getRequestDispatcher("/editdetails.jsp");
				rdisp.include(request, response);
			}
		}

		else
		{
			response.setContentType("text/html");
			request.setAttribute("errorMess", "Invalid LoginID/Password");
			final RequestDispatcher rdisp=request.getRequestDispatcher("/Login.jsp");
			rdisp.include(request, response);
		}
	}

}

