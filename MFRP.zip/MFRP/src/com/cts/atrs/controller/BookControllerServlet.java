/*
 * 
 */
package com.cts.atrs.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.atrs.bo.BookingBO;
import com.cts.atrs.dao.CancelDao;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.CancelFlightModel;
import com.cts.atrs.model.FlightModel;
import com.cts.atrs.model.PassengerModel;
import com.cts.atrs.process.BookingProcess;


// TODO: Auto-generated Javadoc
/**
 * Servlet implementation class BookControllerServlet
 * * The Class BookControllerServlet.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class BookControllerServlet extends HttpServlet {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 333L;

	/** The booking bo. @see HttpServlet#HttpServlet() */

	/** method to generate single instance of bookingBO */
	private transient BookingBO bookingBO;	
	
	/**
	 * Gets the booking bo.
	 *
	 * @return the booking bo
	 */
	public BookingBO getBookingBO() {
		if(bookingBO == null){
			bookingBO = new BookingBO();
		}
		return bookingBO;
	}

	/**
	 * Instantiates a new book controller servlet.
	 */
	public BookControllerServlet() {
		super();
		
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see Servlet#init(ServletConfig)
	 */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		final String action=request.getParameter("action"); // get the specific action to perform
		if("temporaryBook".equals(action))
		{
			if(request.getParameter("fno")== null)
			{
				final RequestDispatcher rdisp=request.getRequestDispatcher("/tempInvoice.jsp");
				rdisp.forward(request, response);
			}
			else
			{
				final BookingProcess bookingProcess = new BookingProcess();
				final BookingBO bookingBO = getBookingBO();
				final FlightModel flight = new FlightModel();
				flight.setAirlineName(request.getParameter("airlineName"));
				flight.setDepartTime(request.getParameter("departTime"));
				flight.setDeptDate(request.getParameter("doj"));
				flight.setDest(request.getParameter("dest"));
				flight.setSrc(request.getParameter("src"));
				flight.setNoOfSeats(Integer.parseInt(request.getParameter("seats")));
				flight.setFare(Integer.parseInt(request.getParameter("fare")));
				flight.setFlightNo(request.getParameter("fno"));
				final HttpSession session = request.getSession();
				final String userName = (String)session.getAttribute("userName");
				final BookFlightModel bookFlightModel = bookingProcess.generateTemporaryBooking(flight,userName, bookingBO);
				session.setAttribute("bookFlightModel", bookFlightModel);
				final RequestDispatcher rdisp=request.getRequestDispatcher("/tempInvoice.jsp");
				rdisp.forward(request, response);
			}

		}
		else if("bookFlightShow".equals(action))
		{
			final HttpSession session = request.getSession();
			List<CancelFlightModel> bookflightShow = new ArrayList<CancelFlightModel>();
			final String customer_id = (String)session.getAttribute("customerId");
			bookflightShow =new CancelDao().getBookedFlights(Integer.parseInt(customer_id));
			session.setAttribute("bookShowList",bookflightShow);
			session.setAttribute("bookFlightLen",bookflightShow.size());
			final RequestDispatcher rdisp=request.getRequestDispatcher("/BookFlightShow.jsp");
			rdisp.forward(request, response);

		}
		else if("cancel".equals(action))
		{
			final HttpSession session = request.getSession();
			session.removeAttribute("bookFlightModel");
			session.removeAttribute("search_result");
			final RequestDispatcher rdisp=request.getRequestDispatcher("/searchflight.jsp");
			rdisp.forward(request, response);
		}
	}
	
	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		final String action=request.getParameter("action"); // get the specific action to perform
		final BookingProcess bookingProcess = new BookingProcess();
		final BookingBO bookingBO = getBookingBO();
		if("confirmTicket".equals(action))
		{
			final HttpSession session = request.getSession();
			final BookFlightModel bookFlightModel = (BookFlightModel)session.getAttribute("bookFlightModel");
			final int customerId = Integer.parseInt((String)session.getAttribute("customerId"));
			final String bookingId = bookingProcess.generateBookingId(bookingBO);
			bookFlightModel.setBookingId(bookingId);
			final String [] names= request.getParameterValues("cname");
			final String [] ages = request.getParameterValues("cage");
			final String [] gender = request.getParameterValues("gender");
			final List <PassengerModel> passengerList = new ArrayList<PassengerModel>();
			for(int i = 0 ; i < names.length ; i ++)
			{
				final PassengerModel passengerModel = new PassengerModel();
				passengerModel.setPassengerName(names[i]);
				passengerModel.setPassengerGender(gender[i]);
				passengerModel.setPassengerAge(Integer.parseInt(ages[i]));
				passengerModel.setBookingId(bookingId);
				passengerModel.setCustomerID(customerId);
				passengerList.add(passengerModel);
			}
			final boolean result = bookingProcess.addPassengerDeatils(passengerList);
			boolean confirmTicket = false ; 
			boolean seatsUpdate = false ;
			if(result)
			{
				confirmTicket = bookingProcess.confirmedTicket(bookFlightModel, bookingBO, customerId);
			}
			else
			{
				final RequestDispatcher rdisp=request.getRequestDispatcher("/errorPage.jsp");
				rdisp.forward(request, response);
			}
			if(confirmTicket)
			{
				seatsUpdate = bookingProcess.updateAvailableSeats(bookFlightModel , bookingBO);
				if(seatsUpdate)
				{
					bookingProcess.removeFlightSearchResultData(bookingBO);
					session.setAttribute("passengerList", passengerList);
					session.setAttribute("finalBookFlightModel", bookFlightModel);
					session.removeAttribute("bookFlightModel");
					session.removeAttribute("search_result");

					final RequestDispatcher rdisp=request.getRequestDispatcher("/invoice.jsp");
					rdisp.forward(request, response);
				}
				else
				{
					final RequestDispatcher rdisp=request.getRequestDispatcher("/errorPage.jsp");
					rdisp.forward(request, response);
				}
			}
			else
			{
				final RequestDispatcher rdisp=request.getRequestDispatcher("/errorPage.jsp");
				rdisp.forward(request, response);
			}
		}


	}

}
