/*
 * 
 */
package com.cts.atrs.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.atrs.dao.CancelDao;
import com.cts.atrs.model.CancelCharges;
import com.cts.atrs.model.CancelFlightModel;
import com.cts.atrs.process.CancelProcess;

// TODO: Auto-generated Javadoc
/**
 * Servlet implementation class CancelControllerServlet.
 */
public class CancelControllerServlet extends HttpServlet {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 332L;
       
    /**
     * Instantiates a new cancel controller servlet.
     *
     * @see HttpServlet#HttpServlet()
     */
    public CancelControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * Inits the.
	 *
	 * @param config the config
	 * @throws ServletException the servlet exception
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		final String action=request.getParameter("action");
		final HttpSession session =request.getSession();
		if(session.isNew()){
			response.sendRedirect("/index.jsp");
		}
		else if("CancelFlightShow".equals(action))
		{
			List<CancelFlightModel> flightCancel = new ArrayList<CancelFlightModel>();
			final String customer_id = (String)session.getAttribute("customerId");
			flightCancel =new CancelDao().getBookedFlights(Integer.parseInt(customer_id));
			session.setAttribute("CancelShowList",flightCancel);
			session.setAttribute("CancelFlightLen",flightCancel.size());
			final RequestDispatcher rdisp=request.getRequestDispatcher("/CancelFlightShow.jsp");
			rdisp.forward(request, response);
			
		}
		else if("tempCancelShow".equals(action))
		{
			final String customer_id = (String)session.getAttribute("customerId");
			final String bookingId = request.getParameter("bookingId");
			final CancelCharges charge = new CancelProcess().calculateCancellation(bookingId, Integer.parseInt(customer_id));
			charge.setBookingId(bookingId);
			session.setAttribute("cancelCharge",charge);
			final RequestDispatcher rdisp=request.getRequestDispatcher("/tempCancelInvoice.jsp");
			rdisp.forward(request, response);
			
		}
		else if("ConfirmCancellation".equals(action))
		{
			final String customer_id = (String)session.getAttribute("customerId");
			final CancelCharges charge = (CancelCharges)session.getAttribute("cancelCharge");
			new CancelDao().saveHistory(charge, Integer.parseInt(customer_id));
			new CancelDao().confirmCancel(charge);
			final RequestDispatcher rdisp=request.getRequestDispatcher("/thankyou.jsp");
			rdisp.forward(request, response);
			
		}
		
	}

	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
