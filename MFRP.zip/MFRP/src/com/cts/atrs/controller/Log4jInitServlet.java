/*
 * 
 */
package com.cts.atrs.controller;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import static java.lang.System.err;




// TODO: Auto-generated Javadoc
/**
 * Servlet implementation class Log4jInitServlet.
 * * The Class Log4jInitServlet.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */
public class Log4jInitServlet extends HttpServlet {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 853L;

	/* (non-Javadoc)
	 * @see javax.servlet.GenericServlet#init(javax.servlet.ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		final String log4jLocation = config.getInitParameter("log4j-properties-location");

		if (log4jLocation == null) {
			err.println("*** No log4j-properties-location init param, so initializing log4j with BasicConfigurator");
			BasicConfigurator.configure();
		}
		else {
			BasicConfigurator.configure();
			PropertyConfigurator.configure("C:\\log4j.properties");
		}
		super.init(config);
	}
}