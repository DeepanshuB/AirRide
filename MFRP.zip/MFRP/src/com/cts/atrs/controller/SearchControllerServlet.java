/*
 * 
 */
package com.cts.atrs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.atrs.bo.SearchBO;
import com.cts.atrs.model.FlightModel;


/**
 * Servlet implementation class SearchFlightController.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public class SearchControllerServlet extends HttpServlet {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4569L;

	/**
	 * Instantiates a new search controller servlet.
	 *
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchControllerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Do get.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}


	/**
	 * Do post.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		final String from= request.getParameter("from");
		final String to= request.getParameter("to");
		final String doj= request.getParameter("doj");
		final String nop= request.getParameter("nop");
		final String depart_time = request.getParameter("depart_time");
		if("".equals(doj))
		{
			response.setContentType("text/html");
			request.setAttribute("errorMessageFlight", "Select Departure Date");
			final RequestDispatcher rdisp=request.getRequestDispatcher("/searchflight.jsp");
			rdisp.include(request, response);
		}
		else
		{
			
			final FlightModel flightModel = new FlightModel();
			flightModel.setDeptDate(doj);
			flightModel.setDepartTime(depart_time);
			flightModel.setDest(to);
			flightModel.setSrc(from);
			flightModel.setNoOfSeats(Integer.parseInt(nop));
			final List<FlightModel> flight = new SearchBO().searchResult(flightModel);
			if(flight.size()==0)
			{
				response.sendRedirect("searchresult.jsp");
			}
			else
			{
				final HttpSession session=request.getSession();
				session.setAttribute("search_result",flight);
				response.sendRedirect("searchresult.jsp");
			}
		}
	}}