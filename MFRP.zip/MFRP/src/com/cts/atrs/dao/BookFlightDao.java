package com.cts.atrs.dao;

import java.util.List;

import com.cts.atrs.exceptions.ApplicationException;
import com.cts.atrs.exceptions.DatabaseOperationException;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.PassengerModel;


// TODO: Auto-generated Javadoc
/**
 * The Interface BookFlightDao.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public interface BookFlightDao
{
	
	/**
	 * Save temp booking data.
	 *
	 * @param bookFlightModel the book flight model
	 * @param date_booking the date_booking
	 * @return true, if successful
	 * @throws DatabaseOperationException the database operation exception
	 * @throws ApplicationException the application exception
	 */
	public boolean saveTempBookingData(BookFlightModel bookFlightModel, String date_booking)throws DatabaseOperationException, ApplicationException;
	
	/**
	 * Generate booking id.
	 *
	 * @return the string
	 * @throws DatabaseOperationException the database operation exception
	 * @throws ApplicationException the application exception
	 */
	public String generateBookingId() throws DatabaseOperationException,  ApplicationException ; //  generating booking Id
	
	/**
	 * Gets the seat availability.
	 *
	 * @param bookFlightModel the book flight model
	 * @return the seat availability
	 * @throws ApplicationException the application exception
	 */
	public int getSeatAvailability(BookFlightModel bookFlightModel) throws ApplicationException; // getting availability of seats
	
	/**
	 * Save confirm booking data.
	 *
	 * @param bookFlightModel the book flight model
	 * @param customerId the customer id
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	public boolean saveConfirmBookingData(BookFlightModel  bookFlightModel, int customerId) throws ApplicationException; //  confirming the ticket
	
	/**
	 * Update seats availability.
	 *
	 * @param bookFlightModel the book flight model
	 * @param availableSeats the available seats
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	boolean updateSeatsAvailability(BookFlightModel bookFlightModel, Integer availableSeats) throws ApplicationException ; // update the availability of seats
	
	/**
	 * Removes the flight search result.
	 *
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	boolean removeFlightSearchResult() throws ApplicationException; // erase the data from temporary search table
	
	/**
	 * Adds the passenger details.
	 *
	 * @param passengerList the passenger list
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	boolean addPassengerDetails(List<PassengerModel> passengerList) throws ApplicationException; // add details of the passengers
}


