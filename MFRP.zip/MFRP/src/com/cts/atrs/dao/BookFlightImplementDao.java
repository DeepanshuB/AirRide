package com.cts.atrs.dao;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.atrs.constants.QueryConstants;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.PassengerModel;
import com.cts.atrs.util.DbUtil;
import com.cts.atrs.exceptions.ApplicationException;
import com.cts.atrs.exceptions.DatabaseOperationException;


// TODO: Auto-generated Javadoc
/**
 * The Class BookFlightImplementDao.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class BookFlightImplementDao implements BookFlightDao
{
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("BookFlightImplementDao.class");
	
	/** The connection. */
	private transient Connection connection = null;
	
	/** The statement. */
	private transient PreparedStatement statement = null;
	
	/** The resultset. */
	private transient ResultSet resultset = null;
	
	/**
	 * method to generate save temporary invoice.
	 *
	 * @param bookFlightModel the book flight model
	 * @param date_booking the date_booking
	 * @return true, if successful
	 * @throws DatabaseOperationException the database operation exception
	 * @throws ApplicationException the application exception
	 */
	public  boolean saveTempBookingData(final BookFlightModel bookFlightModel, final String date_booking)throws DatabaseOperationException, ApplicationException
	{
		boolean result= false ;
		try
		{
			connection= DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.SAVE_TEMP_DATA);
			statement.setString(1,bookFlightModel.getCustomerName());
			statement.setString(2, bookFlightModel.getAirlineName());
			statement.setString(3,bookFlightModel.getFlightId());
			statement.setString(4,bookFlightModel.getLeavingFrom());
			statement.setString(5,bookFlightModel.getGoingTo());
			statement.setInt(6, bookFlightModel.getNumberOfPassenger());
			statement.setString(7,date_booking);
			statement.setInt(8,bookFlightModel.getTotalPrice());
			result = !statement.execute();
		}

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during save temorary booking data", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during save temorary booking data",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during save temorary booking data",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return result ;
	}
	
	/**
	 * method to generate bookingId.
	 *
	 * @return the string
	 * @throws DatabaseOperationException the database operation exception
	 * @throws ApplicationException the application exception
	 */
	public String generateBookingId() throws DatabaseOperationException, ApplicationException 
	{
		String bookingId = "0";

		try
		{
			connection =  DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.GENERATE_ID);
			resultset = statement.executeQuery();
			while(resultset.next())
			{
				bookingId = resultset.getString(1);
			}
		}  

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during generating booking id", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during generating booking id",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during generating booking id",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return bookingId;
	}
	
	/**
	 * method to get seat availability for given flight.
	 *
	 * @param bookFlightModel the book flight model
	 * @return the seat availability
	 * @throws ApplicationException the application exception
	 */
	public int getSeatAvailability(final BookFlightModel bookFlightModel) throws ApplicationException 
	{
		Integer availableSeats = 0 ;
		// TODO Auto-generated method stub

		try 
		{
			connection =  DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.GET_SEATS);
			statement.setString(1,bookFlightModel.getFlightId());
			resultset = statement.executeQuery();
			while(resultset.next())
			{
				availableSeats = resultset.getInt(1);
			}
		} 

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during checking of seat availability", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during checking of seat availability",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during checking of seat availability",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return availableSeats;
	}
	
	/**
	 * method to insert the confirm ticket.
	 *
	 * @param bookFlightModel the book flight model
	 * @param customerId the customer id
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	public boolean saveConfirmBookingData(final BookFlightModel bookFlightModel, final int customerId) throws ApplicationException 
	{
		// TODO Auto-generated method stub
		boolean result = false ;

		try
		{
			connection = DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.INSERT_BOOK_INFO);
			statement.setString(1,bookFlightModel.getBookingId());
			statement.setString(2, bookFlightModel.getBookingDate());
			statement.setString(3,bookFlightModel.getFlightId());
			statement.setInt(4,customerId);
			statement.setInt(5,bookFlightModel.getTotalPrice());
			statement.setInt(6, bookFlightModel.getNumberOfPassenger());
			result = !(statement.execute());
		}

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during confirming booking data", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during confirming booking data",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during confirming booking data",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return result;
	}

	/**
	 * method to update the availability of seat.
	 *
	 * @param bookFlightModel the book flight model
	 * @param availableSeats the available seats
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	public boolean updateSeatsAvailability(final BookFlightModel bookFlightModel, final Integer availableSeats) throws ApplicationException 
	{
		boolean result = false ;
		final Integer updatedSeats = availableSeats - bookFlightModel.getNumberOfPassenger();
		try
		{
			connection =  DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.UPDATE_SEATS);
			statement.setInt(1,updatedSeats);
			statement.setString(2,bookFlightModel.getFlightId());
			statement.setString(3,bookFlightModel.getDateOfJourney());
			result  = !(statement.execute());
		} 

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during updation of seats availability", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during updation of seats availability",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during updation of seats availability",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return result;
	}

	/**
	 * method to erase the data from search temporary table.
	 *
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	public boolean removeFlightSearchResult() throws ApplicationException {
		boolean result = false ;
		try 
		{
			connection =  DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.EMPTY_FLIGHT_DATA);
			result  = !(statement.execute());
		}

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during removing search temporary table", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during removing search temporary table",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during removing search temporary table",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}

		return result;
	}

	/**
	 * method to insert passenger details.
	 *
	 * @param passengerList the passenger list
	 * @return true, if successful
	 * @throws ApplicationException the application exception
	 */
	public boolean addPassengerDetails(List<PassengerModel> passengerList) throws ApplicationException 
	{
		boolean result = false ;
		try
		{
			connection = DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.PASSENGER_DETAIL );
			for (PassengerModel passengerModel : passengerList) 
			{
				statement.setString(1,passengerModel.getBookingId());
				statement.setInt(2, passengerModel.getCustomerID());
				statement.setString(3,passengerModel.getPassengerName());
				statement.setInt(4,passengerModel.getPassengerAge());
				statement.setString(5,passengerModel.getPassengerGender());
				result = !(statement.execute());
			}
		}

		catch(SQLException e)
		{
			throw new DatabaseOperationException("SQL Exception happened during saving passenger data", e);
		}

		catch(ClassNotFoundException e)
		{
			throw new ApplicationException("Class not found exception happened during saving passenger data",e);
		}

		catch(IOException e)
		{
			throw new ApplicationException("Input Output exception happened during saving passenger data",e);
		}

		finally 
		{
			try 
			{ 
				if (resultset != null) 
				{
					resultset.close();
				}
				if (statement != null)
				{
					statement.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException e) 
			{
				LOG.error(e);
			}
		}
		return result ;
	}

}
