package com.cts.atrs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.atrs.constants.QueryConstants;
import com.cts.atrs.model.CancelCharges;
import com.cts.atrs.model.CancelFlightModel;
import com.cts.atrs.util.DbUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class CancelDao.
 *
 * @author 460726
 * This class is used for accessing data from database and make upadation after cancellation.
 */

public class CancelDao implements CancelDaoIntr {
	
	/** The Constant LOG. */
	
	private static final Logger LOG=Logger.getLogger("CancelDao.class");
	
	/** The list. */
	private transient List<CancelFlightModel> list=new  ArrayList<CancelFlightModel>();
	 
	/**
	 * Gets the booked flights.
	 *
	 * @param cust_id the cust_id
	 * @return the booked flights
	 */
	public  List<CancelFlightModel> getBookedFlights(final int cust_id) 
	   {
		
		
		 
		 try{
		 final Connection con = DbUtil.getDbUtilInstance().getConnection();
		 final PreparedStatement stmt = con.prepareStatement(QueryConstants.GET_FLIGHTS);
		 stmt.setInt(1, cust_id);
		 ResultSet result = stmt.executeQuery();
		
		 while(result.next())
		 {
			 CancelFlightModel data=new CancelFlightModel();
			 data.setBookingId(result.getString(1));
			 data.setAname(result.getString(2));
			 data.setSrc(result.getString(5));
			 data.setDest(result.getString(6));
			 data.setDeptdate(result.getString(3));
			 data.setDepartTime(result.getString(4));
			 data.setFare(result.getString(7));
			 data.setNoOfSeats(Integer.parseInt(result.getString(8)));
			 
			 list.add(data);
 		 }
		 }catch (Exception e) {
			 //e.printStackTrace();
			 LOG.error(e);
		}
		 return list;
	   }
	   
	   /**
   	 * Gets the price.
   	 *
   	 * @param booking_id the booking_id
   	 * @param cust_id the cust_id
   	 * @return Total Price of a ticket.
   	 */
	public CancelCharges getPrice(final String booking_id, final int cust_id){
		     CancelCharges cancel = null;
		     try{
			 final Connection connect= DbUtil.getDbUtilInstance().getConnection();
			 final PreparedStatement stmt = connect.prepareStatement(QueryConstants.GET_PRICE);
			 stmt.setString(1, booking_id);
			 stmt.setInt(2, cust_id);
			 final ResultSet result = stmt.executeQuery();
			 if(result.next()){
				  cancel=new CancelCharges();
			      final String date=result.getString(1);
			      final String price=result.getString(2);
			      final String time=result.getString(3);
				  final String total_time=date+" "+time;
				  
				  cancel.setBookingId(booking_id);
				  cancel.setDoj(total_time);
				  cancel.setTotalCost(price);
			 }
			 }catch (Exception e) {
				// e.printStackTrace();
				 LOG.error(e);
			}
			return cancel;
			
		}

	/**
	 * Confirm cancel.
	 *
	 * @param cancel the cancel
	 */
	public  void confirmCancel(final CancelCharges cancel) {
		 int temp_seat_can=0;
		 int temp_seat_ava=0;
		 String temp_fno = null;
		 int flag=0;
		 try{
		 final Connection connect= DbUtil.getDbUtilInstance().getConnection();
		
		 final PreparedStatement stmt3 = connect.prepareStatement(QueryConstants.GET_BOOK_INFO);
		 stmt3.setString(1, cancel.getBookingId());
	
		 ResultSet result = stmt3.executeQuery();
		 if(result.next()) {
			 temp_seat_can=Integer.valueOf(result.getString(1));
			 temp_fno= result.getString(2);
		 }
		 final PreparedStatement stmt5 = connect.prepareStatement(QueryConstants.GET_SEATS);
		 stmt5.setString(1, temp_fno);
		 result= stmt5.executeQuery();
		 if(result.next()) {
			 temp_seat_ava=Integer.valueOf(result.getString(1));
		 }
		 final String total_seat= String.valueOf(temp_seat_ava+temp_seat_can); 
		 
		 
			 final PreparedStatement stmt2 = connect.prepareStatement(QueryConstants.DELETE_BOOKING);
			 stmt2.setString(1, cancel.getBookingId());
			 flag = stmt2.executeUpdate();
		 if(flag!=0) {
			 final PreparedStatement stmt4 = connect.prepareStatement(QueryConstants.UPDATE_CANCEL);
			 stmt4.setString(1,total_seat);
			 stmt4.setString(2, temp_fno);
			 stmt4.executeUpdate();
		 }
		 }catch (Exception e) {
			//e.printStackTrace();
			 LOG.error(e);
		}
	}

	/**
	 * Delete obsolete flight.
	 *
	 * @param booking_id Delete the canceled ticket from database
	 */
	public void deleteObsoleteFlight(final String booking_id){
		try{
		 final Connection con = DbUtil.getDbUtilInstance().getConnection();
		 final PreparedStatement stmt2 = con.prepareStatement(QueryConstants.DELETE_BOOKING);
		 stmt2.setString(1, booking_id);
		 stmt2.execute();
		}catch (Exception e) {
			LOG.info("Connection not created!!");
			LOG.error(e);
			 
		}
	}

	/**
	 * Save history.
	 *
	 * @param canel the canel
	 * @param cid the cid
	 */
	public  void saveHistory(final CancelCharges canel, final int cid) {
		try{
		 final Connection con = DbUtil.getDbUtilInstance().getConnection();
		 final PreparedStatement stmt = con.prepareStatement(QueryConstants.SAVE_HISTORY);
		 stmt.setString(1, canel.getBookingId());
		 stmt.setInt(2, cid);
		 stmt.setString(3, canel.getTotalCost());
		 stmt.setDouble(4, canel.getCharge());
		 stmt.setDouble(5, canel.getRefund());
		 stmt.setDouble(6, canel.getCancelTax());
		 stmt.execute();
		}catch (Exception e) {
			//e.printStackTrace();
			LOG.error(e);
		}
	}
	
	/**
	 * Gets the history.
	 *
	 * @param cid the cid
	 * @return List of all tickets that are cancelled.
	 */
	public  List<CancelCharges> getHistory(final int cid){
		final List<CancelCharges> list = new ArrayList<CancelCharges>();
		try{
		final Connection con= DbUtil.getDbUtilInstance().getConnection();
		final PreparedStatement stmt = con.prepareStatement(QueryConstants.GET_HISTORY);
		stmt.setLong(1, cid);
		final ResultSet result = stmt.executeQuery();
		final CancelCharges cancel = new CancelCharges();
		while(result.next()){
			
			cancel.setBookingId(result.getString("Booking_id"));
			cancel.setCharge(result.getDouble("Refund"));
			cancel.setTotalCost(result.getString("Total"));
			cancel.setCharge(result.getDouble("charge"));
			list.add(cancel);
			
		}
		}catch (Exception e) {
			//e.printStackTrace();
			LOG.error(e);
		}
		return list;
	}
	
}