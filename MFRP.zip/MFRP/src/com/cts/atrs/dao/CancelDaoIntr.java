package com.cts.atrs.dao;

import java.util.List;

import com.cts.atrs.model.CancelCharges;
import com.cts.atrs.model.CancelFlightModel;

// TODO: Auto-generated Javadoc
/**
 * The Interface CancelDaoIntr.
 */
public interface CancelDaoIntr {
	
	/**
	 * Gets the booked flights.
	 *
	 * @param cust_id the cust_id
	 * @return the booked flights
	 */
	List<CancelFlightModel> getBookedFlights(final int cust_id);
	
	/**
	 * Gets the price.
	 *
	 * @param booking_id the booking_id
	 * @param cust_id the cust_id
	 * @return the price
	 */
	CancelCharges getPrice(final String booking_id, final int cust_id);
	
	/**
	 * Confirm cancel.
	 *
	 * @param cancel the cancel
	 */
	 void confirmCancel(final CancelCharges cancel);
	
	/**
	 * Delete obsolete flight.
	 *
	 * @param booking_id the booking_id
	 */
	void deleteObsoleteFlight(final String booking_id);
	
	/**
	 * Save history.
	 *
	 * @param canel the canel
	 * @param cid the cid
	 */
	void saveHistory(final CancelCharges canel, final int cid);
	
	/**
	 * Gets the history.
	 *
	 * @param cid the cid
	 * @return the history
	 */
	List<CancelCharges> getHistory(final int cid);

}
