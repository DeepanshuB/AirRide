package com.cts.atrs.dao;

import static java.lang.System.out;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.cts.atrs.constants.QueryConstants;
import com.cts.atrs.util.DbUtil;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class EditDAO.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 */
public class EditDAO {
	/** The flag. */
	private static transient int flag;
	
	/** The bool. */
	private static transient boolean bool =false;
	
	
	/** The con. */
	private static transient Connection con = null;
	
	/** The pstmt. */
	private static transient PreparedStatement pstmt;
	
	/**
	 * The pstmt1.
	 *
	 * @param userdetails the userdetails
	 * @return true, if successful
	 */
	
	
	/** The Constant LOGER. */
	


	/**
	 * Insert register details.
	 * Takes data from EditBO class as POJO object and inserts values into the database
	 * @param userdetails the userdetails
	 * @return true, if successful
	 */
	public boolean updateUserDetails(final UserDetailsModel userdetails) 

	{

		try

		{
			con = DbUtil.getDbUtilInstance().getConnection();
			pstmt = con.prepareStatement(QueryConstants.UPDATE_USER);
			pstmt.setString(1,userdetails.getName());
			pstmt.setString(2,userdetails.getPassword());
			pstmt.setString(3,userdetails.getDob());
			pstmt.setString(4,userdetails.getAddress());
			pstmt.setString(5,userdetails.getPhone());
			//pstmt.setString(6,userdetails.getGender());
//			pstmt.setString(7,userdetails.getSsnType());
//			pstmt.setString(8,userdetails.getSsnNumber());
			pstmt.setString(6,userdetails.getEmail());
			
			flag = pstmt.executeUpdate();

		}

		catch(Exception ex)

		{
			out.println(ex);
			bool = false;
			
		}
		
		
		if(flag == 1)

		{
			bool = true;

		}

		return bool;
	}
	
	
	

}
