package com.cts.atrs.dao;

import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Interface EditDaoIntr.
 */
public interface EditDaoIntr {
	
	/**
	 * Update user details.
	 *
	 * @param userdetails the userdetails
	 * @return true, if successful
	 */
	boolean updateUserDetails(final UserDetailsModel userdetails);

}
