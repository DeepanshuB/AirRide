package com.cts.atrs.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.atrs.model.UserDetailsModel;
import com.cts.atrs.util.DbUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class HomeViewDao.
 */
public class HomeViewDao implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3471214465828334299L;
	
	/**
	 * Gets the details.
	 *
	 * @param emailid the emailid
	 * @return the details
	 */
	public List<UserDetailsModel> getDetails(String emailid){
		final List<UserDetailsModel> umodelist=new ArrayList<UserDetailsModel>();
		try
		{
			Connection con = DbUtil.getDbUtilInstance().getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from customer_info where email=?");
			ps.setString(1, emailid);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				final UserDetailsModel umode=new UserDetailsModel();
				umode.setCid(rs.getInt("cid"));
				umode.setName(rs.getString("cname"));
				umode.setEmail(rs.getString("email"));
				umode.setPassword(rs.getString("password"));
				umode.setDob(rs.getString("dob"));
				umode.setAddress(rs.getString("address"));
				umode.setPhone(rs.getString("phone"));
				umode.setGender(rs.getString("gender"));
				umode.setSsnType(rs.getString("ssn_type"));
				umode.setSsnNumber(rs.getString("ssn_no"));
				

				umodelist.add(umode);   // adding model object to list
				
				}
		}
		catch(Exception e){e.printStackTrace();}
		return umodelist;
	}
	}

