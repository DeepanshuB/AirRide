package com.cts.atrs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.cts.atrs.constants.QueryConstants;
import com.cts.atrs.model.UserDetailsModel;
import com.cts.atrs.util.DbUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class LoginDao.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 */
public class LoginDAO implements LoginDaoIntr{
	
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("LoginDAO.class");
	/** The pstmt. */
	private static transient PreparedStatement pstmt;
	
	/** The result. */
	private static transient ResultSet result;
	
	/** The bool. */
	private static transient boolean bool;
	
	/**
	 * Validate login dao.
	 * This class validates the login email and password from the database and returns true if successful
	 * @param obj the obj
	 * @return true, if successful
	 */
	public boolean validateLoginDao(final UserDetailsModel obj)// throws  SystemException 
	{

		
	//	vbo = new ValidationBO();
		
		// Getting connection from DbUtil
		  
		try
		{
			//ValidationBO vbo;
			Connection con = DbUtil.getDbUtilInstance().getConnection();
			String email;
			String password;
			bool = false;
			email = obj.getEmail();
			password = obj.getPassword();
			pstmt = con.prepareStatement(QueryConstants.GET_ALL_DETAILS);
			//PreparedStatement details = con.prepareStatement(QueryConstants.GET_ALL_DETAILS);
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			result = pstmt.executeQuery();
			if(result.next())
			{
				bool = true;
				result.previous();
			}
		//	bool = vbo.processDetails(result);
			con.close();
			
		}
		catch(Exception ex)
		{
			LOG.error(ex);
		}
		
		return bool;
	}


}
