package com.cts.atrs.dao;

import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Interface LoginDaoIntr.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 */
public interface LoginDaoIntr {
	
	/**
	 * Validate login dao.
	 * Login Dao Interface
	 * @param obj the obj
	 * @return true, if successful
	 */
	boolean validateLoginDao(final UserDetailsModel obj);

}
