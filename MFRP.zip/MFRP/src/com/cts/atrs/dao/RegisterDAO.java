package com.cts.atrs.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;

import org.apache.log4j.Logger;

import com.cts.atrs.constants.QueryConstants;
import com.cts.atrs.util.DbUtil;
import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Class RegisterDAO.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 */
public class RegisterDAO {
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("RegisterDAO.class");
	/** The flag. */
	private static transient int flag;
	
	/** The bool. */
	private static transient boolean bool =false;
	
	
	/** The con. */
	private static transient Connection con = null;
	
	/** The pstmt. */
	private static transient PreparedStatement pstmt;
	
	
	
	
	/** The Constant LOGER. */
	


	/**
	 * Insert register details.
	 * This class inserts the data into the database which is input from the user
	 * @param userdetails the userdetails
	 * @return true, if successful
	 */
	public boolean insertRegisterDetails(final UserDetailsModel userdetails) 

	{

		try

		{
			
			con = DbUtil.getDbUtilInstance().getConnection();
			pstmt = con.prepareStatement(QueryConstants.INSERT_USER);
			pstmt.setString(1,userdetails.getName());
			pstmt.setString(2,userdetails.getEmail());
			pstmt.setString(3,userdetails.getPassword());
			pstmt.setString(4,userdetails.getDob());
			pstmt.setString(5,userdetails.getAddress());
			pstmt.setString(6,userdetails.getPhone());
			pstmt.setString(7,userdetails.getGender());
			pstmt.setString(8,userdetails.getSsnType());
			pstmt.setString(9,userdetails.getSsnNumber());
			flag = pstmt.executeUpdate();
		

		}

		catch(Exception ex)

		{
			LOG.error(ex);
			bool = false;
			
		}
		
		
		if(flag == 1)

		{
			bool = true;

		}

		return bool;
	}
	
	
	

}
