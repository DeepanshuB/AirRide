package com.cts.atrs.dao;

import com.cts.atrs.model.UserDetailsModel;

// TODO: Auto-generated Javadoc
/**
 * The Interface RegisterDaoIntr.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-30
 */
public interface RegisterDaoIntr {
	
	/**
	 * Insert register details.
	 * Interface of RegisterDao class
	 * @param userdetails the userdetails
	 * @return true, if successful
	 */
	boolean insertRegisterDetails(final UserDetailsModel userdetails);
	

}
