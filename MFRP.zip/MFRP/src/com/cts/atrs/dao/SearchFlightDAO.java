package com.cts.atrs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.cts.atrs.model.*;
import com.cts.atrs.util.DbUtil;
import com.cts.atrs.constants.*;

/**
 * The Class SearchDao Flight.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public class SearchFlightDAO implements SearchFlightDAOIntr
{
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("SearchFlightDAO.class");
	
	/** The connection. */
	private static Connection connection = null;
	
	/** The statement. */
	private static PreparedStatement statement = null;
	
	/** The resultset. */
	private static ResultSet resultset = null;
	
	/* (non-Javadoc)
	 * @see com.cts.atrs.dao.SearchFlightDAOIntr#searchFlight(com.cts.atrs.model.FlightModel)
	 */
	public List<FlightModel> searchFlight(final FlightModel searchTO)
	{
		
		final List <FlightModel> searchFlightList = new ArrayList<FlightModel>();
		
		final String deptdate = searchTO.getDeptDate();
		final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		final SimpleDateFormat sdf1=new SimpleDateFormat("dd/MMM/yyyy");
		Date date = null;
		try {
			date = sdf1.parse(deptdate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			LOG.error(e1);
		}		
		final String ddate =  sdf.format(date);
		try {
			
			connection = DbUtil.getDbUtilInstance().getConnection();
			statement = connection.prepareStatement(QueryConstants.SEARCH_FLIGHT);
			statement.setString(1,searchTO.getSrc());
			statement.setString(2,searchTO.getDest());
			statement.setString(3,ddate);
			statement.setString(4,searchTO.getDepartTime());
			statement.setInt(5,searchTO.getNoOfSeats());
			resultset = statement.executeQuery();
			while(resultset.next())
			{
				final FlightModel flightdetails = new FlightModel();
				flightdetails.setFlightNo(resultset.getString("f_no"));
				flightdetails.setAirlineName(resultset.getString("a_name"));
				flightdetails.setSrc(resultset.getString("src"));
				flightdetails.setDest(resultset.getString("dest"));
				flightdetails.setDepartTime(resultset.getString("depart_time"));
				flightdetails.setFare(resultset.getInt("fare"));
				flightdetails.setDeptDate(ddate);
				flightdetails.setNoOfSeats(searchTO.getNoOfSeats());
				searchFlightList.add(flightdetails);
				insertData(flightdetails);
			}
			
		} 
		catch (Exception e) 
		{	
			LOG.error(e);
		}
		finally
		{
			try 
			{ 
				if (resultset != null) 
				{resultset.close();}
				if (connection != null) 
				{connection.close();}
				if (statement != null) 
				{statement.close();} 
			}catch(Exception e) 
			{
				LOG.error(e);
			}
		}
		return searchFlightList;
	}
	
/**
 * Insert data.
 *
 * @param searchTO the search to
 */
private void insertData(FlightModel searchTO) {
		{
			try {

				connection = DbUtil.getDbUtilInstance().getConnection();
				statement = connection.prepareStatement(QueryConstants.STORE_SEARCH_DATA);
				
				statement.setString(1, searchTO.getFlightNo());
				statement.setString(2, searchTO.getAirlineName());
				statement.setString(3, searchTO.getSrc());
				statement.setString(4, searchTO.getDepartTime());
				statement.setString(5, searchTO.getDest());
				statement.setInt   (6, searchTO.getFare());
				statement.setString(7, searchTO.getDeptDate());
				statement.setInt   (8, searchTO.getNoOfSeats());	
				statement.executeUpdate();
			}
		 
		catch (Exception e) {
			// TODO Auto-generated catch block
			LOG.error(e);
		}
		finally
		{
			try 
			{  
				if (connection != null) 
				{connection.close();} 
				if (statement != null) 
				{statement.close();} 
			} 
			catch (Exception exc) 
			{
				LOG.error(exc);
			}
		}
	  }
	}
}
		
	


	