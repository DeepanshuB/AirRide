package com.cts.atrs.dao;

import java.util.List;
import com.cts.atrs.model.FlightModel;

/**
 * The Interface SearchDao Flight.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public interface SearchFlightDAOIntr
{

	/**
	 * Search flight.
	 *
	 * @param searchTO the search to
	 * @return the list
	 */
	List <FlightModel> searchFlight(FlightModel searchTO);
}
