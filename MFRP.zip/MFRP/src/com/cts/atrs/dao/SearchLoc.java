package com.cts.atrs.dao;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cts.atrs.util.DbUtil;

/**
 * The Class SearchLocation.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public class SearchLoc implements SearchLocIntr{
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("SearchLoc.class");
	
	/** The loc. */
	private String loc;
	
	/* (non-Javadoc)
	 * @see com.cts.atrs.dao.SearchLocIntr#getLoc()
	 */
	public String getLoc() {
		return loc;
	}
	
	/* (non-Javadoc)
	 * @see com.cts.atrs.dao.SearchLocIntr#setLoc(java.lang.String)
	 */
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	/** The connection. */
	Connection connection = null;
	
	/** The statement. */
	PreparedStatement statement = null;
	
	/** The resultset. */
	ResultSet resultset = null;
	
	/* (non-Javadoc)
	 * @see com.cts.atrs.dao.SearchLocIntr#getsearchLocation()
	 */
	public ArrayList<SearchLoc> getsearchLocation()
	{

		ArrayList <SearchLoc> flightLocationList = new ArrayList<SearchLoc>();

		try {
			try {
				connection = DbUtil.getDbUtilInstance().getConnection();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				LOG.error(e);
			}
			statement = connection.prepareStatement("select location_name from location_master");
			resultset = statement.executeQuery();
			while(resultset.next())
			{
				SearchLoc sl = new SearchLoc();
				sl.setLoc(resultset.getString("location_name"));
				flightLocationList.add(sl);	
			}
		} 
		catch (SQLException e) {
			LOG.error(e);
		}
		catch(FileNotFoundException e){
			LOG.error(e);
		}
		catch(IOException e){
			LOG.error(e);
		}



		finally
		{
			try 
			{ 
				if (resultset != null) 
					resultset.close(); 
				if (connection != null) 
					connection.close(); 
				if (statement != null) 
					statement.close(); 
			} 
			catch (Exception e) 
			{
				LOG.error(e);
			}
		}

		return flightLocationList;
	}

}
