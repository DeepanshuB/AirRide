package com.cts.atrs.dao;

import java.util.ArrayList;


/**
 * The Interface SearchLocation.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */
public interface SearchLocIntr {
	
	/**
	 * Gets the loc.
	 *
	 * @return the loc
	 */
	String getLoc();
	
	/**
	 * Sets the loc.
	 *
	 * @param loc the new loc
	 */
	void setLoc(String loc);
	
	/**
	 * Gets the search location.
	 *
	 * @return the search location
	 */
	ArrayList<SearchLoc> getsearchLocation();
}
