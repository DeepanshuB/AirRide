package com.cts.atrs.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


// TODO: Auto-generated Javadoc
/**
 * Servlet Filter implementation class LogoutFilter
 *  * The Class LogoutFilter.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-02-01
 */


public class LogoutFilter implements Filter {

	/** The url list. */
	private ArrayList<String> urlList = null;
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {    }  
	
	/**
	 * method to redirect to login page if user is not login.
	 *
	 * @param req the req
	 * @param resp the resp
	 * @param chain the chain
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ServletException the servlet exception
	 */
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException 
	{                  
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp; 
		HttpSession session = request.getSession(true);
		String url = request.getServletPath();
		boolean allowedRequest = false;
		if(urlList.contains(url)) 
		{            
			allowedRequest = true;        
		}                       
		if (!allowedRequest) 
		{            
			if (null == session || session.getAttribute("userLoggedOn")==null) 
			{                
				response.sendRedirect("index.jsp"); 
				//return;            
			}
			else
			{  
				chain.doFilter(req, resp);
				return; 
			}
		}   
		else if(allowedRequest && session.getAttribute("userLoggedOn") != null)
		{
			response.sendRedirect("searchflight.jsp"); 
		}
		else 
		{      
			chain.doFilter(req, resp);
			return;        
		}             
	}

	/**
	 * init method to get the avoid urls and save it in list.
	 *
	 * @param config the config
	 * @throws ServletException the servlet exception
	 */
	public void init(FilterConfig config) throws ServletException 
	{        
		String urls = config.getInitParameter("avoid_urls");

		StringTokenizer token = new StringTokenizer(urls, ","); 
		urlList = new ArrayList<String>();
		while (token.hasMoreTokens()) 
		{            
			urlList.add(token.nextToken());
		}              

	}

}
