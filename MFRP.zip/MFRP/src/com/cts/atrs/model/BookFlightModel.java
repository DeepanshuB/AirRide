package com.cts.atrs.model;

import java.io.Serializable;


// TODO: Auto-generated Javadoc
/**
 * The Class BookingFlightModel.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class BookFlightModel implements Serializable 
{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 42L;

	//Book Flight Details
	/** The customer name. */
	private String customerName; // name of the customer
	
	/** The airline name. */
	private String airlineName; // name of the air line
	
	/** The leaving from. */
	private String leavingFrom; // source location 
	
	/** The going to. */
	private String goingTo; //destination
	
	/** The number of passenger. */
	private int numberOfPassenger; // number of passenger
	
	/** The departure time. */
	private String departureTime; // time for departure of flight
	
	/** The booking date. */
	private String bookingDate; // date of booking
	
	/** The total price. */
	private int totalPrice; // total price of ticket associated with number of passengers
	
	/** The price. */
	private int price;  // price of each ticket
	
	/** The booking id. */
	private String bookingId; // booking id of ticket
	
	/** The flight id. */
	private String flightId; // id of flight to be booked
	
	/** The date of journey. */
	private String dateOfJourney; // date of journey
	
	/** The discount. */
	private int discount; // discount in price of flight
	
	/** The sub total price. */
	private int subTotalPrice; // total price before discount

	/**
	 * Instantiates a new book flight model.
	 */
	public BookFlightModel() 
	{
		numberOfPassenger = 0 ;
		totalPrice = 0 ;
	}

	/**
	 * Gets the customer name.
	 *
	 * @return the customer name
	 */
	public String getCustomerName() 
	{
		return customerName;
	}

	/**
	 * Sets the customer name.
	 *
	 * @param customerName the new customer name
	 */
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}

	/**
	 * Gets the airline name.
	 *
	 * @return the airline name
	 */
	public String getAirlineName() 
	{
		return airlineName;
	}

	/**
	 * Sets the airline name.
	 *
	 * @param airlineName the new airline name
	 */
	public void setAirlineName(String airlineName) 
	{
		this.airlineName = airlineName;
	}

	/**
	 * Gets the leaving from.
	 *
	 * @return the leaving from
	 */
	public String getLeavingFrom() {
		return leavingFrom;
	}

	/**
	 * Sets the leaving from.
	 *
	 * @param leavingFrom the new leaving from
	 */
	public void setLeavingFrom(String leavingFrom)
	{
		this.leavingFrom = leavingFrom;
	}

	/**
	 * Gets the going to.
	 *
	 * @return the going to
	 */
	public String getGoingTo() 
	{
		return goingTo;
	}

	/**
	 * Sets the going to.
	 *
	 * @param goingTo the new going to
	 */
	public void setGoingTo(String goingTo) 
	{
		this.goingTo = goingTo;
	}

	/**
	 * Gets the number of passenger.
	 *
	 * @return the number of passenger
	 */
	public int getNumberOfPassenger()
	{
		return numberOfPassenger;
	}

	/**
	 * Sets the number of passenger.
	 *
	 * @param numberOfPassenger the new number of passenger
	 */
	public void setNumberOfPassenger(int numberOfPassenger) 
	{
		this.numberOfPassenger = numberOfPassenger;
	}

	/**
	 * Gets the departure time.
	 *
	 * @return the departure time
	 */
	public String getDepartureTime() 
	{
		return departureTime;
	}

	/**
	 * Sets the departure time.
	 *
	 * @param departureTime the new departure time
	 */
	public void setDepartureTime(String departureTime)
	{
		this.departureTime = departureTime;
	}

	/**
	 * Gets the booking date.
	 *
	 * @return the booking date
	 */
	public String getBookingDate() 
	{
		return bookingDate;
	}

	/**
	 * Sets the booking date.
	 *
	 * @param bookingDate the new booking date
	 */
	public void setBookingDate(String bookingDate) 
	{
		this.bookingDate = bookingDate;
	}

	/**
	 * Gets the total price.
	 *
	 * @return the total price
	 */
	public int getTotalPrice() 
	{
		return totalPrice;
	}

	/**
	 * Sets the total price.
	 *
	 * @param totalPrice the new total price
	 */
	public void setTotalPrice(int totalPrice) 
	{
		this.totalPrice = totalPrice;
	}

	/**
	 * Gets the price.
	 *
	 * @return the price
	 */
	public int getPrice() 
	{
		return price;
	}

	/**
	 * Sets the price.
	 *
	 * @param price the new price
	 */
	public void setPrice(int price) 
	{
		this.price = price;
	}

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() 
	{
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) 
	{
		this.bookingId = bookingId;
	}

	/**
	 * Gets the flight id.
	 *
	 * @return the flight id
	 */
	public String getFlightId() 
	{
		return flightId;
	}

	/**
	 * Sets the flight id.
	 *
	 * @param flightId the new flight id
	 */
	public void setFlightId(String flightId) 
	{
		this.flightId = flightId;
	}

	/**
	 * Gets the date of journey.
	 *
	 * @return the date of journey
	 */
	public String getDateOfJourney() 
	{
		return dateOfJourney;
	}

	/**
	 * Sets the date of journey.
	 *
	 * @param dateOfJourney the new date of journey
	 */
	public void setDateOfJourney(String dateOfJourney) 
	{
		this.dateOfJourney = dateOfJourney;
	}



	/**
	 * Gets the discount.
	 *
	 * @return the discount
	 */
	public int getDiscount() {
		return discount;
	}

	/**
	 * Sets the discount.
	 *
	 * @param discount the new discount
	 */
	public void setDiscount(int discount) {
		this.discount = discount;
	}

	/**
	 * Gets the sub total price.
	 *
	 * @return the sub total price
	 */
	public int getSubTotalPrice() {
		return subTotalPrice;
	}

	/**
	 * Sets the sub total price.
	 *
	 * @param subTotalPrice the new sub total price
	 */
	public void setSubTotalPrice(int subTotalPrice) {
		this.subTotalPrice = subTotalPrice;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BookFlightModel [customerName=" + customerName
		                         + ", airlineName=" + airlineName + ", leavingFrom="
		                         + leavingFrom + ", goingTo=" + goingTo
		                         + ", numberOfPassenger=" + numberOfPassenger
		                         + ", departureTime=" + departureTime + ", bookingDate="
		                         + bookingDate + ", totalPrice=" + totalPrice + ", price="
		                         + price + ", bookingId=" + bookingId + ", flightId="
		                         + flightId + ", dateOfJourney=" + dateOfJourney
		                         + ", discount=" + discount + ", subTotalPrice=" + subTotalPrice + "]";
	}





}
