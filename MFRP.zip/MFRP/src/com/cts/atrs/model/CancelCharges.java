package com.cts.atrs.model;

import java.io.Serializable;


// TODO: Auto-generated Javadoc
/**
 * The Class CancelCharges.
 *
 * @author 460726
 * This class is used to get and set the public variables used in ticket cancellation.
 */




public class CancelCharges implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 459L;
	
	/** The charge. */
	private double charge; // Cancellation Charge on a ticket.
	
	/** The total cost. */
	private String totalCost; //Total Amount you paid at the time of booking.
	
	/** The doj. */
	private String doj; //Date of Journey of passenger.
	
	/** The cancel tax. */
	private double cancelTax;

	/** The type. */
	private char type; //Defines which cancellation criteria will be applied.
	
	/** The refund. */
	private double refund; //Refundable Amount after cancellation.
	
	/** The booking id. */
	private  String bookingId; //Booking ID of ticket.
	
	
	/**
	 * Gets the cancel tax.
	 *
	 * @return the cancel tax
	 */
	public double getCancelTax() {
		return cancelTax;
	}
	
	/**
	 * Sets the cancel tax.
	 *
	 * @param cancelTax the new cancel tax
	 */
	public void setCancelTax(double cancelTax) {
		this.cancelTax = cancelTax;
	}
	
	/**
	 * Gets the charge.
	 *
	 * @return the charge
	 */
	public double getCharge() {
		return charge;
	}
	
	/**
	 * Sets the charge.
	 *
	 * @param charge the new charge
	 */
	public void setCharge(double charge) {
		this.charge = charge;
	}
	
	/**
	 * Gets the total cost.
	 *
	 * @return the total cost
	 */
	public String getTotalCost() {
		return totalCost;
	}
	
	/**
	 * Sets the total cost.
	 *
	 * @param totalCost the new total cost
	 */
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	
	/**
	 * Gets the doj.
	 *
	 * @return the doj
	 */
	public String getDoj() {
		return doj;
	}
	
	/**
	 * Sets the doj.
	 *
	 * @param doj the new doj
	 */
	public void setDoj(String doj) {
		this.doj = doj;
	}
	
	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public char getType() {
		return type;
	}
	
	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(char type) {
		this.type = type;
	}
	
	/**
	 * Gets the refund.
	 *
	 * @return the refund
	 */
	public double getRefund() {
		return refund;
	}
	
	/**
	 * Sets the refund.
	 *
	 * @param refund the new refund
	 */
	public void setRefund(double refund) {
		this.refund = refund;
	}
	
	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId() {
		return bookingId;
	}
	
	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CancelCharges [charge=" + charge + ", totalCost=" + totalCost
				+ ", doj=" + doj + ", cancelTax=" + cancelTax + ", type="
				+ type + ", refund=" + refund + ", bookingId=" + bookingId
				+ "]";
	}
	
	

}
