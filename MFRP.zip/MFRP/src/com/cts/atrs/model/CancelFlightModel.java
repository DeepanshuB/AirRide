package com.cts.atrs.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class CancelFlightModel.
 *
 * @author 460726
 * This class is used to create a model which is used to view the necessary details at the time of cancellation.
 */

public class CancelFlightModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 958L;
	
	/** The bookingid. */
	private transient String bookingid; // Booking_ID of a ticket.
	
	/** The deptdate. */
	private transient String deptdate; // Departure Date of ba flight.
	
	/** The src. */
	private String src; // Source of flight.
	
	/** The dest. */
	private String dest; // Destination of flight.
	
	/** The departtime. */
	private transient String departtime; // Departure time of a flight.
	
	/** The fare. */
	private String fare; // Total fare of a ticket booked.
	
	/** The aname. */
	private transient String aname; // Name of a airlines.
	
	/** The no of seats. */
	private transient int noOfSeats;
	
	/**
	 * Gets the no of seats.
	 *
	 * @return the no of seats
	 */
	public int getNoOfSeats() {
		return noOfSeats;
	}

	/**
	 * Sets the no of seats.
	 *
	 * @param noOfSeats the new no of seats
	 */
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	/**
	 * Gets the bookingid.
	 *
	 * @return Booking ID of a ticket.
	 */
	public String getBookingid() {
		return bookingid;
	}
	
	/**
	 * Sets the booking id.
	 *
	 * @param booking_id Sets Booking ID of a ticket.
	 */
	public void setBookingId(final String booking_id) {
		this.bookingid = booking_id;
	}
	
	/**
	 * Gets the deptdate.
	 *
	 * @return Departure Date of a flight.
	 */
	public String getDeptdate() {
		return deptdate;
	}
	
	/**
	 * Sets the deptdate.
	 *
	 * @param dept_date Sets Departure Date of a flight.
	 */
	public void setDeptdate(final String dept_date) {
		this.deptdate = dept_date;
	}
	
	/**
	 * Gets the src.
	 *
	 * @return Source of a flight.
	 */
	public String getSrc() {
		return src;
	}
	
	/**
	 * Sets the src.
	 *
	 * @param src Sets Source of a flight.
	 */
	public void setSrc(final String src) {
		this.src = src;
	}
	
	/**
	 * Gets the dest.
	 *
	 * @return Destination of a flight.
	 */
	public String getDest() {
		return dest;
	}
	
	/**
	 * Sets the dest.
	 *
	 * @param dest Sets Destination of a flight.
	 */
	public void setDest(final String dest) {
		this.dest = dest;
	}
	
	/**
	 * Gets the departtime.
	 *
	 * @return Departure Time of a flight.
	 */
	public String getDeparttime() {
		return departtime;
	}
	
	/**
	 * Sets the depart time.
	 *
	 * @param depart_time Sets Departure Time of a flight.
	 */
	public void setDepartTime(final String depart_time) {
		this.departtime = depart_time;
	}
	
	/**
	 * Gets the fare.
	 *
	 * @return Total Fare of a ticket.
	 */
	public String getFare() {
		return fare;
	}
	
	/**
	 * Sets the fare.
	 *
	 * @param fare Sets Total Fare of a ticket.
	 */
	public void setFare(final String fare) {
		this.fare = fare;
	}
	
	/**
	 * Gets the aname.
	 *
	 * @return Name of a Airlines.
	 */
	public String getAname() {
		return aname;
	}
	
	/**
	 * Sets the aname.
	 *
	 * @param a_name Sets Name of a Airlines.
	 */
	public void setAname(final String a_name) {
		this.aname = a_name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CancelFlightModel [bookingid=" + bookingid + ", deptdate="
				+ deptdate + ", src=" + src + ", dest=" + dest
				+ ", departtime=" + departtime + ", fare=" + fare + ", aname="
				+ aname + ", noOfSeats=" + noOfSeats + "]";
	}	
	
}