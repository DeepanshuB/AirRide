package com.cts.atrs.model;

import java.io.Serializable;


// TODO: Auto-generated Javadoc
/**
 * The Class FlightModel.
 * 
 * @author Deepanshu Bansal
 * @version 1.0
 * @since 2015-01-28
 */

public class FlightModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 45L;
	
	/** The flight no. */
	private String flightNo;
	
	/** The no of seats. */
	private int noOfSeats;
	
	/** The dept date. */
	private String deptDate;
	
	/** The src. */
	private String src;
	
	/** The dest. */
	private String dest;
	
	/** The depart time. */
	private String departTime;
	
	/** The fare. */
	private int fare;
	
	/** The airline name. */
	private String airlineName;
	
	/**
	 * Gets the flight no.
	 *
	 * @return the flight no
	 */
	public String getFlightNo() 
	{
		return flightNo;
	}
	
	/**
	 * Sets the flight no.
	 *
	 * @param flightNo the new flight no
	 */
	public void setFlightNo(String flightNo) 
	{
		this.flightNo = flightNo;
	}
	
	/**
	 * Gets the no of seats.
	 *
	 * @return the no of seats
	 */
	public int getNoOfSeats()
	{
		return noOfSeats;
	}
	
	/**
	 * Sets the no of seats.
	 *
	 * @param noOfSeats the new no of seats
	 */
	public void setNoOfSeats(int noOfSeats) 
	{
		this.noOfSeats = noOfSeats;
	}
	
	/**
	 * Gets the dept date.
	 *
	 * @return the dept date
	 */
	public String getDeptDate() 
	{
		return deptDate;
	}
	
	/**
	 * Sets the dept date.
	 *
	 * @param deptDate the new dept date
	 */
	public void setDeptDate(String deptDate) 
	{
		this.deptDate = deptDate;
	}
	
	/**
	 * Gets the src.
	 *
	 * @return the src
	 */
	public String getSrc() 
	{
		return src;
	}
	
	/**
	 * Sets the src.
	 *
	 * @param src the new src
	 */
	public void setSrc(String src) 
	{
		this.src = src;
	}
	
	/**
	 * Gets the dest.
	 *
	 * @return the dest
	 */
	public String getDest() 
	{
		return dest;
	}
	
	/**
	 * Sets the dest.
	 *
	 * @param dest the new dest
	 */
	public void setDest(String dest)
	{
		this.dest = dest;
	}
	
	/**
	 * Gets the depart time.
	 *
	 * @return the depart time
	 */
	public String getDepartTime() 
	{
		return departTime;
	}
	
	/**
	 * Sets the depart time.
	 *
	 * @param departTime the new depart time
	 */
	public void setDepartTime(String departTime) 
	{
		this.departTime = departTime;
	}
	
	/**
	 * Gets the fare.
	 *
	 * @return the fare
	 */
	public int getFare() 
	{
		return fare;
	}
	
	/**
	 * Sets the fare.
	 *
	 * @param fare the new fare
	 */
	public void setFare(int fare) 
	{
		this.fare = fare;
	}
	
	/**
	 * Gets the airline name.
	 *
	 * @return the airline name
	 */
	public String getAirlineName() 
	{
		return airlineName;
	}
	
	/**
	 * Sets the airline name.
	 *
	 * @param airlineName the new airline name
	 */
	public void setAirlineName(String airlineName) 
	{
		this.airlineName = airlineName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FlightModel [flightNo=" + flightNo + ", noOfSeats=" + noOfSeats
				+ ", deptDate=" + deptDate + ", src=" + src + ", dest=" + dest
				+ ", departTime=" + departTime + ", fare=" + fare
				+ ", airlineName=" + airlineName + "]";
	}
	
	
}
