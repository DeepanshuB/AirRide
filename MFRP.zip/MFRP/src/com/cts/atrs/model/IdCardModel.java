package com.cts.atrs.model;

import java.io.Serializable;

// TODO: Auto-generated Javadoc
/**
 * The Class IdCardModel.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class IdCardModel implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 189L;
	
	/** The ssn_type. */
	private String ssnType;

	/**
	 * Instantiates a new id card model.
	 */
	public IdCardModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gets the ssn_type.
	 *
	 * @return the ssn_type
	 */
	public String getSsnType() {
		return ssnType;
	}

	/**
	 * Sets the ssn_type.
	 *
	 * @param ssn_type the new ssn_type
	 */
	public void setSsnType(String ssnType) {
		this.ssnType = ssnType;
	}

	/**
	 * Instantiates a new id card model.
	 *
	 * @param ssn_type the ssn_type
	 */
	public IdCardModel(String ssn_type) {
		super();
		this.ssnType = ssn_type;
	}
	
}
