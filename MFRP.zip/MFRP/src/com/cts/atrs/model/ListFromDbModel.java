package com.cts.atrs.model;

import java.util.ArrayList;

import com.cts.atrs.util.DbUtil;

import java.io.Serializable;
import java.sql.*;

// TODO: Auto-generated Javadoc
/**
 * The Class ListFromDbModel.
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 */
public class ListFromDbModel implements Serializable{

	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 856L;

	/**
	 * Gets the ssntypes.
	 *
	 * @return the ssntypes
	 */
	public ArrayList<IdCardModel> getSsntypes()
	{
		final ArrayList<IdCardModel> IdList = new ArrayList<IdCardModel>();
		try
		{
			Connection con = DbUtil.getDbUtilInstance().getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select ssn_type from ssn_master");
			while(rs.next())
			{
				IdCardModel ic = new IdCardModel();
				ic.setSsnType(rs.getString("ssn_type"));
				IdList.add(ic);
			}
		}
		catch(Exception e){e.printStackTrace();}
		return IdList;
	}

	
}
