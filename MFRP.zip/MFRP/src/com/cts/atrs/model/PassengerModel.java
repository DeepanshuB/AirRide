package com.cts.atrs.model;

import java.io.Serializable;


// TODO: Auto-generated Javadoc
/**
 * The Class PassengerModel.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class PassengerModel implements Serializable
{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 126L;
	
	/** The booking id. */
	private String bookingId; // booking id of ticket
	
	/** The customer id. */
	private Integer customerID; // id of customer who is logge din
	
	/** The passenger name. */
	private String passengerName; // name of the passenger
	
	/** The passenger age. */
	private Integer passengerAge; // age of the passenger
	
	/** The passenger gender. */
	private String passengerGender; // gender of passenger Male/Female

	/**
	 * Gets the booking id.
	 *
	 * @return the booking id
	 */
	public String getBookingId()
	{
		return bookingId;
	}

	/**
	 * Sets the booking id.
	 *
	 * @param bookingId the new booking id
	 */
	public void setBookingId(String bookingId) 
	{
		this.bookingId = bookingId;
	}

	/**
	 * Gets the customer id.
	 *
	 * @return the customer id
	 */
	public Integer getCustomerID() 
	{
		return customerID;
	}

	/**
	 * Sets the customer id.
	 *
	 * @param customerID the new customer id
	 */
	public void setCustomerID(Integer customerID) 
	{
		this.customerID = customerID;
	}

	/**
	 * Gets the passenger name.
	 *
	 * @return the passenger name
	 */
	public String getPassengerName() 
	{
		return passengerName;
	}

	/**
	 * Sets the passenger name.
	 *
	 * @param passengerName the new passenger name
	 */
	public void setPassengerName(String passengerName) 
	{
		this.passengerName = passengerName;
	}

	/**
	 * Gets the passenger age.
	 *
	 * @return the passenger age
	 */
	public Integer getPassengerAge()
	{
		return passengerAge;
	}

	/**
	 * Sets the passenger age.
	 *
	 * @param passengerAge the new passenger age
	 */
	public void setPassengerAge(Integer passengerAge) 
	{
		this.passengerAge = passengerAge;
	}

	/**
	 * Gets the passenger gender.
	 *
	 * @return the passenger gender
	 */
	public String getPassengerGender() 
	{
		return passengerGender;
	}

	/**
	 * Sets the passenger gender.
	 *
	 * @param passengerGender the new passenger gender
	 */
	public void setPassengerGender(String passengerGender) 
	{
		this.passengerGender = passengerGender;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PassengerModel [bookingId=" + bookingId + ", customerID="
				+ customerID + ", passengerName=" + passengerName
				+ ", passengerAge=" + passengerAge + ", passengerGender="
				+ passengerGender + "]";
	}
	
	
}
