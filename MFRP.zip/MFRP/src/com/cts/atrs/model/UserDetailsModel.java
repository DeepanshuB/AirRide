package com.cts.atrs.model;

import java.io.Serializable;



// TODO: Auto-generated Javadoc
/**
 * @author Ishant Agarwal
 * @version 1.0
 * @since 2015-01-24
 * The Class UserDetailsModel acts as POJO for whole module.
 */
public class UserDetailsModel implements Serializable
{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 185L;

	/** The name. */
	private String name;
	
	/** The email. */
	private String email;
	
	/** The password. */
	private String password;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserDetailsModel [name=" + name + ", email=" + email
				+ ", password=" + password + ", dob=" + dob + ", address="
				+ address + ", phone=" + phone + ", gender=" + gender
				+ ", ssnType=" + ssnType + ", ssnNumber=" + ssnNumber
				+ ", flag=" + flag + ", cid=" + cid + "]";
	}

	/** The dob. */
	private String dob;
	
	/** The address. */
	private String address;
	
	/** The phone. */
	private String phone;
	
	/** The gender. */
	private String gender;
	
	/** The ssn type. */
	private String ssnType;
	
	/** The ssn number. */
	private String ssnNumber;
	
	/** The flag. */
	private boolean flag = true;
	
	/** The cid. */
	private int cid ;


	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(final String name) {
		this.name = name;
	}
	
	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void setEmail(final String email) {
		this.email = email;
	}
	
	/**
	 * Gets the dob.
	 *
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}
	
	/**
	 * Sets the dob.
	 *
	 * @param dob the new dob
	 */
	public void setDob(final String dob) {
		this.dob = dob;
	}
	
	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	
	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(final String address) {
		this.address = address;
	}
	
	/**
	 * Gets the phone.
	 *
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	
	/**
	 * Sets the phone.
	 *
	 * @param string the new phone
	 */
	public void setPhone(final String string) {
		this.phone = string;
	}
	
	/**
	 * Gets the ssn type.
	 *
	 * @return the ssn type
	 */
	public String getSsnType() {
		return ssnType;
	}
	
	/**
	 * Sets the ssn type.
	 *
	 * @param string the new ssn type
	 */
	public void setSsnType(final String string) {
		this.ssnType = string;
	}
	
	/**
	 * Gets the ssn number.
	 *
	 * @return the ssn number
	 */
	public String getSsnNumber() {
		return ssnNumber;
	}
	
	/**
	 * Sets the ssn number.
	 *
	 * @param string the new ssn number
	 */
	public void setSsnNumber(final String string) {
		this.ssnNumber = string;
	}
	
	/**
	 * Checks if is flag.
	 *
	 * @return true, if is flag
	 */
	public boolean isFlag() {
		return flag;
	}
	
	/**
	 * Sets the flag.
	 *
	 * @param flag the new flag
	 */
	public void setFlag(final boolean flag) {
		this.flag = flag;
	}
	//	public RegisterProcess getRegprocess() {
	//		return regprocess;
	//	}
	//	public void setRegprocess(RegisterProcess regprocess) {
	//		this.regprocess = regprocess;
	//	}

	/**
	 * Gets the gender.
	 *
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * Sets the gender.
	 *
	 * @param gender the new gender
	 */
	public void setGender(final String gender) {
		// TODO Auto-generated method stub
		this.gender = gender;

	}
	
	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(final String password) {
		this.password = password;
	}
	
	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Gets the cid.
	 *
	 * @return the cid
	 */
	public int getCid() {
		return cid;
	}

	/**
	 * Sets the cid.
	 *
	 * @param cid the new cid
	 */
	public void setCid(int cid) {
		this.cid = cid;
	}
	


}
