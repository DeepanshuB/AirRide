package com.cts.atrs.process;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.atrs.bo.BookingBO;
import com.cts.atrs.model.BookFlightModel;
import com.cts.atrs.model.FlightModel;
import com.cts.atrs.model.PassengerModel;


// TODO: Auto-generated Javadoc
/**
 * The Class BookingProcess.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */

public class BookingProcess
{
	
	/** The Constant LOG. */
	private static final Logger LOG=Logger.getLogger("BookingProcess.class"); 
	
	/** The date booking. */
	private transient String dateBooking ;


	/**
	 * Generate temporary booking.
	 *
	 * @param flight the flight
	 * @param passangerName the passanger name
	 * @param bookingBO the booking bo
	 * @return the book flight model
	 */
	public BookFlightModel generateTemporaryBooking(final FlightModel flight , final String passangerName, final BookingBO bookingBO) 
	{
		final BookFlightModel bookFlightModel=new BookFlightModel();
		final Date date = new Date();
		final SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-YYYY");
		dateBooking = sdf.format(date);
		final int cost=flight.getFare();
		final int seats=flight.getNoOfSeats();
		final int discount = 150 * flight.getNoOfSeats() ;
		final int subTotalPrice = seats*cost;
		final int totalPrice = subTotalPrice - discount ;
		bookFlightModel.setAirlineName(flight.getAirlineName());
		bookFlightModel.setCustomerName(passangerName);
		bookFlightModel.setDateOfJourney(flight.getDeptDate());
		bookFlightModel.setDepartureTime(flight.getDepartTime());
		bookFlightModel.setFlightId(flight.getFlightNo());
		bookFlightModel.setGoingTo(flight.getDest());
		bookFlightModel.setLeavingFrom(flight.getSrc());
		bookFlightModel.setPrice(flight.getFare());
		bookFlightModel.setTotalPrice(totalPrice);
		bookFlightModel.setNumberOfPassenger(flight.getNoOfSeats());
		bookFlightModel.setBookingDate(dateBooking);
		bookFlightModel.setDiscount(discount);
		bookFlightModel.setSubTotalPrice(subTotalPrice);
		bookingBO.isValidBookData(bookFlightModel, dateBooking);
		return bookFlightModel;
	}

	/**
	 * Check seat availability.
	 *
	 * @param bookFlightModel the book flight model
	 * @param bookingBO the booking bo
	 * @return true, if successful
	 */
	public boolean checkSeatAvailability(final BookFlightModel bookFlightModel, final BookingBO bookingBO)
	{
		boolean result = false ;
		result = bookingBO.isSeatAvailable(bookFlightModel);
		return result ;
	}

	/**
	 * Generate booking id.
	 *
	 * @param bookingBO the booking bo
	 * @return the string
	 */
	public String generateBookingId(final BookingBO bookingBO)
	{
		String bookingId = null ;
		try
		{
			final String tempBookingId = bookingBO.getBookingId();
			String subString = "0"; 
			if(tempBookingId.length() >= 3)
			{
				subString = tempBookingId.substring(tempBookingId.length() - 3);
			}
			final int temp = Integer.parseInt(subString) + 1;
			subString =String.valueOf(temp);
			bookingId = "ABK010" + subString ;
		}
		catch(Exception e)
		{
			LOG.error("Error occur in generating bookingId "+e);
		}
		return bookingId;
	}

	/**
	 * Confirmed ticket.
	 *
	 * @param bookFlightModel the book flight model
	 * @param bookingBO the booking bo
	 * @param customerId the customer id
	 * @return true, if successful
	 */
	public boolean confirmedTicket(final BookFlightModel bookFlightModel, final BookingBO bookingBO, final int customerId)
	{
		boolean result = false ;
		try
		{
			result = bookingBO.isValidConfirmedBookData(bookFlightModel, customerId);
		}
		catch(Exception e)
		{
			LOG.error(e);
		}
		return result ;

	}

	/**
	 * Update available seats.
	 *
	 * @param bookFlightModel the book flight model
	 * @param bookingBO the booking bo
	 * @return true, if successful
	 */
	public boolean updateAvailableSeats(final BookFlightModel bookFlightModel , final BookingBO bookingBO)
	{
		boolean result = false;
		result = bookingBO.isSeatsUpdated(bookFlightModel);
		return result ;
	}

	/**
	 * Removes the flight search result data.
	 *
	 * @param bookingBO the booking bo
	 * @return true, if successful
	 */
	public boolean removeFlightSearchResultData(final BookingBO bookingBO) 
	{
		return bookingBO.isFlightSearchResultDeleted();
	}


	/**
	 * Adds the passenger deatils.
	 *
	 * @param passengerList the passenger list
	 * @return true, if successful
	 */
	public boolean addPassengerDeatils(final List<PassengerModel> passengerList) 
	{
		boolean result = false ;
		result = new BookingBO().isPassengerDetailsSaved(passengerList);
		return result ;
	}

}
