package com.cts.atrs.process;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.cts.atrs.dao.CancelDao;
import com.cts.atrs.model.CancelCharges;

import static java.lang.System.out;
// TODO: Auto-generated Javadoc

/**
 * The Class CancelProcess.
 */
public class CancelProcess {
	
	//private Date date;

	/** calculateCancellation() is used to calculate refundable money incase flight is canceled Input :- Booking ID and Customer ID Output:- Cancel Model Object. */
	private static final Logger LOG=Logger.getLogger("CancelProcess.class");
	
	/**
	 * Calculate cancellation.
	 *
	 * @param booking_id the booking_id
	 * @param cust_id the cust_id
	 * @return the cancel charges
	 */
	public CancelCharges calculateCancellation(final String booking_id,final  int cust_id) {
		final Calendar doj = Calendar.getInstance();
		final Calendar today = Calendar.getInstance();
		final Date currentdate = new Date();
		today.setTime(currentdate);
		final Calendar tendays = Calendar.getInstance();
		final Calendar fivedays = Calendar.getInstance();
		final Calendar tomorrow = Calendar.getInstance();
		final Calendar nextday = Calendar.getInstance();
		double cancel_charge = 0;
		double refuncharges = 0;
		double fare = 0;
		double cancel_tax = 0 ;
		final SimpleDateFormat simpledateformat = new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.ENGLISH);
		final CancelCharges cancel_obj = new CancelDao().getPrice(booking_id, cust_id);
		Date date_of_journey = null;
		try 
		{
			date_of_journey = simpledateformat.parse(cancel_obj.getDoj());
		} 
		catch (ParseException e) 
		{
			// TODO Auto-generated catch block
	
			//e.printStackTrace();
			LOG.error(e);
		}
		doj.setTime(date_of_journey);
		tendays.setTime(date_of_journey);			
		tendays.add(Calendar.DAY_OF_MONTH, -10);
		fivedays.setTime(date_of_journey);
		fivedays.add(Calendar.DAY_OF_MONTH, -5);
		nextday.add(Calendar.DAY_OF_MONTH, +1);
		tomorrow.setTime(date_of_journey);
		tomorrow.add(Calendar.DAY_OF_MONTH, -1);
		fare = Double.valueOf(cancel_obj.getTotalCost());
		
		if (nextday.after(doj) && doj.after(today)) 
		{
			out.println("You cannot cancel ticket of today's journey\nThankyou");
			cancel_obj.setType('0');
		} 
		else if (tendays.after(today) || tendays.equals(today)) {
			cancel_charge = 0.1 * fare;
			cancel_tax = 0.2 * cancel_charge ;
			refuncharges = fare - cancel_charge - cancel_tax;
			cancel_obj.setCharge(cancel_charge);
			cancel_obj.setRefund(refuncharges);
			cancel_obj.setCancelTax(cancel_tax);
			cancel_obj.setType('1');
		} 
		else if (fivedays.after(today) || fivedays.equals(today)) {
			cancel_charge = 0.2 * fare;
			cancel_tax = 0.2 * cancel_charge ;
			refuncharges = fare - cancel_charge - cancel_tax;
			cancel_obj.setCharge(cancel_charge);
			cancel_obj.setRefund(refuncharges);
			cancel_obj.setCancelTax(cancel_tax);
			cancel_obj.setType('2');
		} 
		else if (tomorrow.after(today) || tomorrow.equals(today)) {
			cancel_charge = 0.5 * fare;
			cancel_tax = 0.2 * cancel_charge ;
			refuncharges = fare - cancel_charge - cancel_tax;
			cancel_obj.setCharge(cancel_charge);
			cancel_obj.setRefund(refuncharges);
			cancel_obj.setCancelTax(cancel_tax);
			cancel_obj.setType('3');
		} 
		else if (today.after(doj)) {
			cancel_obj.setType('4');
			
		}
		
		return cancel_obj;
	}
}
