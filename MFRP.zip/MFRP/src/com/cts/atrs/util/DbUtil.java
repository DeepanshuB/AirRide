package com.cts.atrs.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

// TODO: Auto-generated Javadoc
/**
 * The Class DbUtil.
 * 
 * @author Saurabh Bhatia
 * @version 1.0
 * @since 2015-01-28
 */
public final class DbUtil 
{

		/** The connection. */
		private static DbUtil dbUtilObj = new DbUtil( );

		/**
		 * Gets the connection.
		 *
		 * @return the connection
		 */
	
		/*A private Constructor prevents any other  class from instantiating.*/
		private DbUtil() {}

		/**
		 * Gets the db util instance.
		 *
		 * @return the db util instance
		 */
		public static DbUtil getDbUtilInstance()
		{
			if (null == dbUtilObj) 
			{
				dbUtilObj = new DbUtil();
			}
			return dbUtilObj;
		}
	
		/**
		 * Gets the connection.
		 *
		 * @return the connection
		 * @throws ClassNotFoundException the class not found exception
		 * @throws IOException Signals that an I/O exception has occurred.
		 * @throws SQLException the sQL exception
		 */
		public  Connection getConnection() throws ClassNotFoundException,IOException, SQLException 
		{
			Connection connection = null;
			final Properties prop = new Properties();
			prop.load(new FileInputStream("C:\\db.properties"));
			final String driver = prop.getProperty("driver");
			final String url = prop.getProperty("url");
			final String user = prop.getProperty("user");
			final String password = prop.getProperty("password");
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			return connection;
		}
}
